"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type ChatRole = "user" | "assistant";

type ChatMessage = {
  id: string;
  role: ChatRole;
  content: string;
};

type OrgAiCopilotProps = {
  slug: string;
};

type ActionType =
  | "chat"
  | "create_okr"
  | "generate_jtbd"
  | "create_tasks"
  | "rewrite_kpi"
  | "diagnose_underperformance";

type SseEvent = {
  event: string;
  data: string;
};

type ResponseCompletedPayload = {
  response?: {
    output?: Array<{
      type?: string;
      role?: string;
      content?: Array<{
        type?: string;
        text?: string;
      }>;
    }>;
  };
};

type ActionPreviewResponse = {
  ok?: boolean;
  error?: string;
  action?: string;
  mode?: "preview" | "executed";
  preview?: Record<string, unknown>;
  wrote?: boolean;
  entity?: string;
  summary?: string;
  message?: string;
  created?: Record<string, unknown> | null;
};

type PreviewState = {
  action: Exclude<ActionType, "chat">;
  prompt: string;
  data: Record<string, unknown>;
};

function uid() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function parseSseEvents(chunk: string) {
  const normalized = chunk.replace(/\r\n/g, "\n");
  const blocks = normalized.split("\n\n");
  const completeBlocks = blocks.slice(0, -1);
  const remainder = blocks[blocks.length - 1] ?? "";

  const events: SseEvent[] = [];

  for (const block of completeBlocks) {
    const lines = block.split("\n");
    let event = "";
    const dataParts: string[] = [];

    for (const line of lines) {
      if (line.startsWith(":")) continue;

      if (line.startsWith("event:")) {
        event = line.slice(6).trim();
        continue;
      }

      if (line.startsWith("data:")) {
        dataParts.push(line.slice(5).trim());
      }
    }

    const data = dataParts.join("\n");
    if (data) {
      events.push({ event, data });
    }
  }

  return { events, remainder };
}

function extractTextFromCompletedEvent(payload: ResponseCompletedPayload): string {
  const outputs = payload.response?.output ?? [];
  const parts: string[] = [];

  for (const item of outputs) {
    if (item.type !== "message") continue;

    for (const content of item.content ?? []) {
      if (content.type === "output_text" && typeof content.text === "string" && content.text.trim()) {
        parts.push(content.text);
      }
    }
  }

  return parts.join("\n").trim();
}

function labelForAction(action: ActionType) {
  switch (action) {
    case "chat":
      return "Ask Your AI";
    case "create_okr":
      return "Create OKR";
    case "generate_jtbd":
      return "Generate JTBD";
    case "create_tasks":
      return "Create Tasks";
    case "rewrite_kpi":
      return "Rewrite KPI";
    case "diagnose_underperformance":
      return "Diagnose Underperformance";
  }
}

function placeholderForAction(action: ActionType) {
  switch (action) {
    case "chat":
      return "Ask about KPI underperformance, blocked execution, OKR quality, JTBD gaps, weak ownership, or what leadership should do next.";
    case "create_okr":
      return "Example: Create a Q2 OKR for Sales to improve qualified pipeline and close rate under the revenue objective.";
    case "generate_jtbd":
      return "Example: Generate JTBD for Customer Success to improve onboarding completion and reduce early churn.";
    case "create_tasks":
      return "Example: Create execution tasks for the most at-risk KR in the Sales department.";
    case "rewrite_kpi":
      return "Example: Rewrite the KPI 'Increase sales' into a measurable KPI with baseline, target, unit, and formula.";
    case "diagnose_underperformance":
      return "Example: Diagnose why the company is underperforming this quarter and tell me the biggest blockers.";
  }
}

function asObject(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null;
}

function asArray(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function asString(value: unknown) {
  return typeof value === "string" ? value : "";
}

function renderPrettyJson(value: unknown) {
  return JSON.stringify(value, null, 2);
}

function actionCardClass(active: boolean) {
  return active
    ? "border-white/18 bg-white text-black"
    : "border-white/10 bg-black/20 text-white hover:bg-white/8";
}

function chipClass(light = false) {
  return light
    ? "rounded-full border border-black/10 bg-black/5 px-2.5 py-1 text-[11px] font-semibold text-black/70"
    : "rounded-full border border-white/10 bg-white/6 px-2.5 py-1 text-[11px] font-semibold text-white/72";
}

const actionCards: Array<{
  key: ActionType;
  title: string;
  description: string;
}> = [
  {
    key: "chat",
    title: "Ask Your AI",
    description: "Live streamed answers grounded in objectives, OKRs, key results, KPIs, JTBD, and tasks.",
  },
  {
    key: "diagnose_underperformance",
    title: "Diagnose Underperformance",
    description: "Analyze what is off track and what should be fixed next.",
  },
  {
    key: "create_okr",
    title: "Create OKR",
    description: "Generate a preview for one OKR and linked key results before saving.",
  },
  {
    key: "generate_jtbd",
    title: "Generate JTBD",
    description: "Preview a JTBD cluster and linked execution tasks before saving.",
  },
  {
    key: "create_tasks",
    title: "Create Tasks",
    description: "Generate a task plan mapped to your strategy chain.",
  },
  {
    key: "rewrite_kpi",
    title: "Rewrite KPI",
    description: "Improve a weak KPI into a measurable, structured KPI before saving.",
  },
];

function PreviewPanel({
  preview,
  onApprove,
  onDiscard,
  executing,
}: {
  preview: PreviewState | null;
  onApprove: () => void;
  onDiscard: () => void;
  executing: boolean;
}) {
  if (!preview) return null;

  const data = preview.data;
  const summary = asString(data.summary);
  const okr = asObject(data.okr);
  const cluster = asObject(data.cluster);
  const kpi = asObject(data.kpi);
  const diagnosis = asString(data.diagnosis);
  const causes = asArray(data.causes);
  const actions = asArray(data.actions);
  const updates = asObject(data.suggested_updates);

  return (
    <section className="rounded-[28px] border border-white/10 bg-black/25 p-5">
      <div className="flex flex-col gap-4 border-b border-white/8 pb-4 md:flex-row md:items-start md:justify-between">
        <div>
          <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
            Preview
          </div>
          <h3 className="mt-2 text-xl font-black tracking-[-0.03em] text-white">
            {labelForAction(preview.action)}
          </h3>
          {summary ? <p className="mt-2 text-sm leading-7 text-white/60">{summary}</p> : null}
        </div>

        <div className="flex gap-2">
          {preview.action !== "diagnose_underperformance" ? (
            <button
              type="button"
              onClick={onApprove}
              disabled={executing}
              className={`rounded-2xl px-4 py-2.5 text-sm font-semibold transition ${
                executing
                  ? "cursor-not-allowed border border-white/8 bg-white/10 text-white/35"
                  : "border border-white/12 bg-white text-black hover:opacity-95"
              }`}
            >
              {executing ? "Approving..." : "Approve & Save"}
            </button>
          ) : null}

          <button
            type="button"
            onClick={onDiscard}
            disabled={executing}
            className="rounded-2xl border border-white/10 bg-white/6 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10 disabled:opacity-50"
          >
            {preview.action === "diagnose_underperformance" ? "Close" : "Discard"}
          </button>
        </div>
      </div>

      <div className="mt-5 space-y-4">
        {preview.action === "create_okr" && okr ? (
          <>
            <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
                OKR
              </div>
              <div className="mt-2 text-lg font-bold text-white">{asString(okr.title) || "Untitled OKR"}</div>
              {asString(okr.description) ? (
                <p className="mt-2 whitespace-pre-wrap text-sm leading-7 text-white/60">
                  {asString(okr.description)}
                </p>
              ) : null}
              <div className="mt-3 flex flex-wrap gap-2">
                <span className={chipClass()}>{`Objective ID: ${asString(okr.objective_id) || "—"}`}</span>
                <span className={chipClass()}>{`Department ID: ${asString(okr.department_id) || "—"}`}</span>
                <span className={chipClass()}>{`Owner ID: ${asString(okr.owner_user_id) || "—"}`}</span>
                <span className={chipClass()}>{`Status: ${asString(okr.status) || "draft"}`}</span>
                <span className={chipClass()}>{`Progress: ${String(okr.progress ?? 0)}%`}</span>
              </div>
            </div>

            <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
                Key Results
              </div>
              <div className="mt-3 space-y-3">
                {asArray(okr.key_results).map((item, index) => {
                  const kr = asObject(item) ?? {};
                  return (
                    <div key={index} className="rounded-2xl border border-white/8 bg-black/20 p-4">
                      <div className="text-sm font-semibold text-white">
                        {asString(kr.title) || `Key Result ${index + 1}`}
                      </div>
                      <div className="mt-2 flex flex-wrap gap-2">
                        <span className={chipClass()}>{`Metric: ${asString(kr.metric_name) || "—"}`}</span>
                        <span className={chipClass()}>{`Current: ${String(kr.current_value ?? 0)} ${asString(kr.unit)}`}</span>
                        <span className={chipClass()}>{`Target: ${String(kr.target_value ?? 0)} ${asString(kr.unit)}`}</span>
                        <span className={chipClass()}>{`Status: ${asString(kr.status) || "not_started"}`}</span>
                        <span className={chipClass()}>{`Owner ID: ${asString(kr.owner_user_id) || "—"}`}</span>
                        <span className={chipClass()}>{`KPI ID: ${asString(kr.kpi_id) || "—"}`}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        ) : null}

        {(preview.action === "generate_jtbd" || preview.action === "create_tasks") && cluster ? (
          <>
            <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
                Cluster
              </div>
              <div className="mt-2 text-lg font-bold text-white">{asString(cluster.title) || "Untitled Cluster"}</div>
              {asString(cluster.description) ? (
                <p className="mt-2 whitespace-pre-wrap text-sm leading-7 text-white/60">
                  {asString(cluster.description)}
                </p>
              ) : null}
              <div className="mt-3 flex flex-wrap gap-2">
                <span className={chipClass()}>{`Department ID: ${asString(cluster.department_id) || "—"}`}</span>
                <span className={chipClass()}>{`Objective ID: ${asString(cluster.objective_id) || "—"}`}</span>
                <span className={chipClass()}>{`OKR ID: ${asString(cluster.okr_id) || "—"}`}</span>
                <span className={chipClass()}>{`KR ID: ${asString(cluster.key_result_id) || "—"}`}</span>
                <span className={chipClass()}>{`Owner ID: ${asString(cluster.owner_user_id) || "—"}`}</span>
                <span className={chipClass()}>{`Status: ${asString(cluster.status) || "draft"}`}</span>
              </div>
            </div>

            <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
                Tasks
              </div>
              <div className="mt-3 space-y-3">
                {asArray(data.tasks).map((item, index) => {
                  const task = asObject(item) ?? {};
                  return (
                    <div key={index} className="rounded-2xl border border-white/8 bg-black/20 p-4">
                      <div className="text-sm font-semibold text-white">
                        {asString(task.title) || `Task ${index + 1}`}
                      </div>
                      {asString(task.description) ? (
                        <p className="mt-2 whitespace-pre-wrap text-sm leading-7 text-white/60">
                          {asString(task.description)}
                        </p>
                      ) : null}
                      <div className="mt-2 flex flex-wrap gap-2">
                        <span className={chipClass()}>{`Priority: ${asString(task.priority) || "medium"}`}</span>
                        <span className={chipClass()}>{`Status: ${asString(task.status) || "todo"}`}</span>
                        <span className={chipClass()}>{`Owner ID: ${asString(task.assigned_to_user_id) || "—"}`}</span>
                        <span className={chipClass()}>{`Due: ${asString(task.due_date) || "—"}`}</span>
                        <span className={chipClass()}>{`KPI ID: ${asString(task.kpi_id) || "—"}`}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        ) : null}

        {preview.action === "rewrite_kpi" && kpi ? (
          <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
            <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
              KPI
            </div>
            <div className="mt-2 text-lg font-bold text-white">{asString(kpi.title) || "Untitled KPI"}</div>
            {asString(kpi.description) ? (
              <p className="mt-2 whitespace-pre-wrap text-sm leading-7 text-white/60">
                {asString(kpi.description)}
              </p>
            ) : null}
            <div className="mt-3 flex flex-wrap gap-2">
              <span className={chipClass()}>{`Mode: ${asString(data.mode) || "create"}`}</span>
              <span className={chipClass()}>{`Existing KPI ID: ${asString(data.existing_kpi_id) || "—"}`}</span>
              <span className={chipClass()}>{`Department ID: ${asString(kpi.department_id) || "—"}`}</span>
              <span className={chipClass()}>{`Owner ID: ${asString(kpi.owner_user_id) || "—"}`}</span>
              <span className={chipClass()}>{`Current: ${String(kpi.current_value ?? 0)} ${asString(kpi.unit)}`}</span>
              <span className={chipClass()}>{`Target: ${String(kpi.target_value ?? 0)} ${asString(kpi.unit)}`}</span>
              <span className={chipClass()}>{`Direction: ${asString(kpi.direction) || "increase"}`}</span>
              <span className={chipClass()}>{`Frequency: ${asString(kpi.frequency) || "monthly"}`}</span>
              <span className={chipClass()}>{`Measurement: ${asString(kpi.measurement_type) || "number"}`}</span>
              <span className={chipClass()}>{`Formula: ${asString(kpi.formula) || "—"}`}</span>
            </div>
            {asString(data.history_note) ? (
              <div className="mt-3 rounded-2xl border border-white/8 bg-black/20 p-3 text-sm text-white/65">
                <span className="font-semibold text-white">History note:</span> {asString(data.history_note)}
              </div>
            ) : null}
          </div>
        ) : null}

        {preview.action === "diagnose_underperformance" ? (
          <>
            {diagnosis ? (
              <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
                <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
                  Diagnosis
                </div>
                <p className="mt-2 whitespace-pre-wrap text-sm leading-7 text-white/70">{diagnosis}</p>
              </div>
            ) : null}

            {causes.length ? (
              <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
                <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
                  Causes
                </div>
                <div className="mt-3 space-y-2">
                  {causes.map((cause, index) => (
                    <div key={index} className="rounded-2xl border border-white/8 bg-black/20 p-3 text-sm text-white/70">
                      {asString(cause)}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            {actions.length ? (
              <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
                <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
                  Recommended Actions
                </div>
                <div className="mt-3 space-y-2">
                  {actions.map((action, index) => (
                    <div key={index} className="rounded-2xl border border-white/8 bg-black/20 p-3 text-sm text-white/70">
                      {asString(action)}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}

            {updates ? (
              <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
                <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
                  Suggested Updates
                </div>
                <div className="mt-4 grid gap-4 lg:grid-cols-3">
                  <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
                    <div className="text-sm font-semibold text-white">KPIs</div>
                    <div className="mt-3 space-y-2">
                      {asArray(updates.kpis).length ? (
                        asArray(updates.kpis).map((item, index) => (
                          <div key={index} className="text-sm leading-7 text-white/65">
                            • {asString(item)}
                          </div>
                        ))
                      ) : (
                        <div className="text-sm text-white/35">No KPI updates suggested.</div>
                      )}
                    </div>
                  </div>

                  <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
                    <div className="text-sm font-semibold text-white">OKRs</div>
                    <div className="mt-3 space-y-2">
                      {asArray(updates.okrs).length ? (
                        asArray(updates.okrs).map((item, index) => (
                          <div key={index} className="text-sm leading-7 text-white/65">
                            • {asString(item)}
                          </div>
                        ))
                      ) : (
                        <div className="text-sm text-white/35">No OKR updates suggested.</div>
                      )}
                    </div>
                  </div>

                  <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
                    <div className="text-sm font-semibold text-white">Tasks</div>
                    <div className="mt-3 space-y-2">
                      {asArray(updates.tasks).length ? (
                        asArray(updates.tasks).map((item, index) => (
                          <div key={index} className="text-sm leading-7 text-white/65">
                            • {asString(item)}
                          </div>
                        ))
                      ) : (
                        <div className="text-sm text-white/35">No task updates suggested.</div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        ) : null}

        {!okr && !cluster && !kpi && !diagnosis ? (
          <div className="rounded-[22px] border border-white/10 bg-white/5 p-4">
            <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-white/35">
              Raw Preview
            </div>
            <pre className="mt-3 overflow-x-auto whitespace-pre-wrap text-sm leading-7 text-white/65">
              {renderPrettyJson(data)}
            </pre>
          </div>
        ) : null}
      </div>
    </section>
  );
}

export default function OrgAiCopilot({ slug }: OrgAiCopilotProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: uid(),
      role: "assistant",
      content:
        "Your AI is connected to your workspace. Ask about KPIs, OKRs, objectives, JTBD, tasks, blockers, or execution gaps. Or switch to an action and generate a preview before saving.",
    },
  ]);
  const [input, setInput] = useState("");
  const [mode, setMode] = useState<ActionType>("chat");
  const [loading, setLoading] = useState(false);
  const [executingPreview, setExecutingPreview] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<PreviewState | null>(null);

  const messagesRef = useRef<HTMLDivElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  const canSend = useMemo(() => input.trim().length > 0 && !loading && !executingPreview, [input, loading, executingPreview]);

  useEffect(() => {
    const el = messagesRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages, loading]);

  async function getToken() {
    const { data } = await supabase.auth.getSession();
    const session = data.session;

    if (!session?.access_token) {
      throw new Error("You are not authenticated.");
    }

    return session.access_token;
  }

  async function sendChat(prompt: string) {
    const token = await getToken();

    const userMessage: ChatMessage = {
      id: uid(),
      role: "user",
      content: prompt,
    };

    const assistantMessage: ChatMessage = {
      id: uid(),
      role: "assistant",
      content: "",
    };

    const nextMessages = [...messages, userMessage, assistantMessage];
    setMessages(nextMessages);

    const response = await fetch(`/api/o/${encodeURIComponent(slug)}/ai/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        messages: nextMessages.map((message) => ({
          role: message.role,
          content: message.content,
        })),
      }),
    });

    if (!response.ok || !response.body) {
      const raw = await response.text().catch(() => "");
      let errorMessage = raw || `AI request failed (${response.status})`;

      try {
        const parsed = JSON.parse(raw) as { error?: string; detail?: string };
        errorMessage = parsed.detail || parsed.error || errorMessage;
      } catch {
        // ignore
      }

      throw new Error(errorMessage);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    let buffer = "";
    let fullText = "";
    let completedText = "";

    while (true) {
      const { done, value } = await reader.read();

      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      const parsed = parseSseEvents(buffer);
      buffer = parsed.remainder;

      for (const event of parsed.events) {
        if (event.data === "[DONE]") continue;

        const payload = JSON.parse(event.data) as Record<string, unknown>;

        if (event.event === "response.output_text.delta") {
          const delta = typeof payload.delta === "string" ? payload.delta : "";
          if (delta) {
            fullText += delta;

            setMessages((prev) =>
              prev.map((message) =>
                message.id === assistantMessage.id
                  ? { ...message, content: fullText }
                  : message
              )
            );
          }
          continue;
        }

        if (event.event === "response.output_text.done") {
          const text = typeof payload.text === "string" ? payload.text : "";
          if (text) {
            fullText = text;

            setMessages((prev) =>
              prev.map((message) =>
                message.id === assistantMessage.id
                  ? { ...message, content: fullText }
                  : message
              )
            );
          }
          continue;
        }

        if (event.event === "response.completed") {
          completedText = extractTextFromCompletedEvent(
            payload as ResponseCompletedPayload
          );

          if (completedText) {
            fullText = completedText;

            setMessages((prev) =>
              prev.map((message) =>
                message.id === assistantMessage.id
                  ? { ...message, content: fullText }
                  : message
              )
            );
          }
          continue;
        }

        if (event.event === "response.failed") {
          const responseError =
            typeof (payload.response as { error?: { message?: string } } | undefined)?.error
              ?.message === "string"
              ? (payload.response as { error?: { message?: string } }).error!.message!
              : "The model failed to generate a response.";

          throw new Error(responseError);
        }
      }
    }

    if (!fullText.trim() && !completedText.trim()) {
      setMessages((prev) =>
        prev.map((message) =>
          message.id === assistantMessage.id
            ? { ...message, content: "No response was returned. Try again." }
            : message
        )
      );
    }
  }

  async function sendActionPreview(action: Exclude<ActionType, "chat">, prompt: string) {
    const token = await getToken();

    const response = await fetch(`/api/o/${encodeURIComponent(slug)}/ai/actions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        action,
        prompt,
      }),
    });

    const raw = await response.text().catch(() => "");
    const parsed = raw ? (JSON.parse(raw) as ActionPreviewResponse) : null;

    if (!response.ok || !parsed?.ok || parsed.mode !== "preview" || !parsed.preview) {
      throw new Error(parsed?.error || `Preview failed (${response.status})`);
    }

    setPreview({
      action,
      prompt,
      data: parsed.preview,
    });

    const assistantMessage = `Preview ready for ${labelForAction(action)}. Review it below, then approve to save.`;
    setMessages((prev) => [
      ...prev,
      {
        id: uid(),
        role: "assistant",
        content: assistantMessage,
      },
    ]);
  }

  async function approvePreview() {
    if (!preview) return;

    setExecutingPreview(true);
    setError(null);

    try {
      const token = await getToken();

      const response = await fetch(`/api/o/${encodeURIComponent(slug)}/ai/actions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
          "X-AI-Mode": "execute",
        },
        body: JSON.stringify({
          action: preview.action,
          prompt: preview.prompt,
          preview: preview.data,
        }),
      });

      const raw = await response.text().catch(() => "");
      const parsed = raw ? (JSON.parse(raw) as ActionPreviewResponse) : null;

      if (!response.ok || !parsed?.ok) {
        throw new Error(parsed?.error || `Execution failed (${response.status})`);
      }

      setMessages((prev) => [
        ...prev,
        {
          id: uid(),
          role: "assistant",
          content: parsed.message || parsed.summary || `${labelForAction(preview.action)} completed.`,
        },
      ]);

      setPreview(null);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to execute preview";
      setError(message);
    } finally {
      setExecutingPreview(false);
    }
  }

  async function handleSend() {
    const prompt = input.trim();
    if (!prompt || loading || executingPreview) return;

    setLoading(true);
    setError(null);
    setInput("");

    try {
      if (mode === "chat") {
        setPreview(null);
        await sendChat(prompt);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: uid(),
            role: "user",
            content: `${labelForAction(mode)}\n${prompt}`,
          },
        ]);
        await sendActionPreview(mode, prompt);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Something went wrong";
      setError(message);
      setMessages((prev) => [
        ...prev,
        {
          id: uid(),
          role: "assistant",
          content: `Error: ${message}`,
        },
      ]);
    } finally {
      setLoading(false);
      textareaRef.current?.focus();
    }
  }

  return (
    <section className="space-y-6">
      <section className="rounded-[32px] border border-white/10 bg-white/5 shadow-[var(--app-shadow)]">
        <div className="flex flex-col gap-4 border-b border-white/8 px-5 py-5 md:flex-row md:items-start md:justify-between md:px-6">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.18em] text-white/35">
              Real-time AI workspace
            </div>
            <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-white">
              Your AI
            </h2>
            <p className="mt-2 max-w-3xl text-sm leading-7 text-white/55">
              Stream answers, preview structured actions, and approve changes before they write into your workspace.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              if (loading || executingPreview) return;
              setError(null);
              setPreview(null);
              setMode("chat");
              setMessages([
                {
                  id: uid(),
                  role: "assistant",
                  content:
                    "Your AI was cleared. Ask a question or choose an action to generate a preview.",
                },
              ]);
            }}
            className="rounded-2xl border border-white/10 bg-white/6 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10"
          >
            Clear
          </button>
        </div>

        <div className="grid gap-3 border-b border-white/8 px-5 py-5 md:grid-cols-2 xl:grid-cols-3 md:px-6">
          {actionCards.map((card) => {
            const active = mode === card.key;

            return (
              <button
                key={card.key}
                type="button"
                disabled={loading || executingPreview}
                onClick={() => {
                  setMode(card.key);
                  setError(null);
                  textareaRef.current?.focus();
                }}
                className={`rounded-[24px] border p-4 text-left transition ${actionCardClass(active)}`}
              >
                <div
                  className={`text-[11px] font-semibold uppercase tracking-[0.16em] ${
                    active ? "text-black/55" : "text-white/35"
                  }`}
                >
                  {card.key === "chat" ? "Chat" : "Action"}
                </div>
                <div className="mt-2 text-lg font-bold">{card.title}</div>
                <div className={`mt-2 text-sm leading-6 ${active ? "text-black/70" : "text-white/55"}`}>
                  {card.description}
                </div>
              </button>
            );
          })}
        </div>

        <div
          ref={messagesRef}
          className="max-h-[46vh] min-h-[360px] space-y-4 overflow-y-auto px-5 py-5 md:px-6"
        >
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[88%] rounded-[24px] border px-4 py-4 md:max-w-[76%] ${
                  message.role === "user"
                    ? "border-white/12 bg-white text-black"
                    : "border-white/10 bg-black/25 text-white"
                }`}
              >
                <div
                  className={`mb-2 text-[11px] font-semibold uppercase tracking-[0.16em] ${
                    message.role === "user" ? "text-black/55" : "text-white/35"
                  }`}
                >
                  {message.role === "user" ? "You" : "Your AI"}
                </div>

                <div className="whitespace-pre-wrap text-sm leading-7">
                  {message.content || (loading && message.role === "assistant" ? "Thinking..." : "")}
                </div>
              </div>
            </div>
          ))}

          {error ? (
            <div className="rounded-2xl border border-red-400/20 bg-red-400/10 px-4 py-3 text-sm text-red-100">
              {error}
            </div>
          ) : null}
        </div>

        <div className="border-t border-white/8 px-5 py-5 md:px-6">
          <div className="mb-3 flex flex-wrap gap-2">
            {[
              "What are the biggest execution risks right now?",
              "Create a Q2 OKR for revenue growth",
              "Generate JTBD for onboarding improvement",
              "Create tasks for the most at-risk KR",
              "Rewrite the weakest KPI in this workspace",
              "Diagnose underperformance this quarter",
            ].map((prompt) => (
              <button
                key={prompt}
                type="button"
                disabled={loading || executingPreview}
                onClick={() => setInput(prompt)}
                className="rounded-full border border-white/10 bg-white/6 px-3 py-2 text-xs font-medium text-white/72 transition hover:bg-white/10 disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>

          <div className="mb-3 flex items-center gap-2">
            <div className="rounded-full border border-white/10 bg-white/6 px-3 py-1.5 text-xs font-semibold text-white/75">
              Current mode
            </div>
            <div className="rounded-full border border-white/12 bg-white px-3 py-1.5 text-xs font-semibold text-black">
              {labelForAction(mode)}
            </div>
          </div>

          <div className="rounded-[26px] border border-white/10 bg-black/25 p-3">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void handleSend();
                }
              }}
              rows={5}
              placeholder={placeholderForAction(mode)}
              className="w-full resize-none bg-transparent px-2 py-2 text-sm leading-7 text-white outline-none placeholder:text-white/28"
            />

            <div className="mt-3 flex flex-col gap-3 border-t border-white/8 pt-3 md:flex-row md:items-center md:justify-between">
              <div className="text-xs text-white/35">
                Enter to send • Shift+Enter for new line • Chat streams live • Actions generate preview first
              </div>

              <button
                type="button"
                onClick={() => void handleSend()}
                disabled={!canSend}
                className={`rounded-2xl px-5 py-3 text-sm font-semibold transition ${
                  canSend
                    ? "border border-white/12 bg-white text-black hover:opacity-95"
                    : "cursor-not-allowed border border-white/8 bg-white/10 text-white/35"
                }`}
              >
                {loading
                  ? mode === "chat"
                    ? "Streaming..."
                    : "Generating Preview..."
                  : mode === "chat"
                  ? "Send"
                  : `Preview ${labelForAction(mode)}`}
              </button>
            </div>
          </div>
        </div>
      </section>

      <PreviewPanel
        preview={preview}
        onApprove={() => void approvePreview()}
        onDiscard={() => setPreview(null)}
        executing={executingPreview}
      />
    </section>
  );
}