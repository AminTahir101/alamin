"use client";

import type React from "react";
import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/app/lib/supabaseClient";

type Department = { id: string; name: string };

type Kpi = {
  id: string;
  title: string;
  department_id: string;
  department_name?: string | null;
  current_value: number;
  target_value: number;
  weight: number;
  is_active: boolean;
  last_recorded_at?: string | null;
  source?: string | null;
};

type Cycle = { id: string; year: number; quarter: number; status: string };

type ListPayload = {
  ok: boolean;
  cycle?: Cycle | null;
  departments?: Department[];
  kpis?: Kpi[];
  error?: string;
  detail?: unknown;
};

function getErrorMessage(err: unknown, fallback: string) {
  if (err instanceof Error) return err.message;
  if (typeof err === "string") return err;
  if (err && typeof err === "object") {
    const o = err as { message?: unknown; error?: unknown; detail?: unknown };
    if (typeof o.message === "string" && o.message.trim()) return o.message;
    if (typeof o.error === "string" && o.error.trim()) return o.error;
    if (typeof o.detail === "string" && o.detail.trim()) return o.detail;
  }
  return fallback;
}

async function safeParseJson(text: string): Promise<unknown> {
  if (!text.trim()) return null;
  try {
    return JSON.parse(text) as unknown;
  } catch {
    return null;
  }
}

function fmtDate(iso?: string | null) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString();
}

export default function KpisPage() {
  const params = useParams<{ slug: string }>();
  const orgSlug = String(params?.slug ?? "").trim();
  const router = useRouter();

  const [sessionEmail, setSessionEmail] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);

  const [cycle, setCycle] = useState<Cycle | null>(null);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [kpis, setKpis] = useState<Kpi[]>([]);

  const [creating, setCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [form, setForm] = useState({
    title: "",
    department_id: "",
    current_value: "0",
    target_value: "0",
    weight: "1",
    is_active: true,
    notes: "",
  });

  const canSubmit = useMemo(() => {
    if (!form.title.trim()) return false;
    if (!form.department_id.trim()) return false;
    const c = Number(form.current_value);
    const t = Number(form.target_value);
    const w = Number(form.weight);
    if (!Number.isFinite(c) || !Number.isFinite(t) || !Number.isFinite(w) || w <= 0) return false;
    return true;
  }, [form]);

  async function ensureAuth(): Promise<Session | null> {
    const { data } = await supabase.auth.getSession();
    const session = data.session;
    setSessionEmail(session?.user?.email ?? null);
    if (!session) {
      router.replace("/auth");
      return null;
    }
    return session;
  }

  async function load() {
    setMsg(null);
    setLoading(true);

    try {
      const session = await ensureAuth();
      if (!session) return;

      const res = await fetch(`/api/o/${encodeURIComponent(orgSlug)}/kpis`, {
        method: "GET",
        headers: { Authorization: `Bearer ${session.access_token}` },
        cache: "no-store",
      });

      const raw = await res.text();
      const parsedUnknown = await safeParseJson(raw);
      const parsed = parsedUnknown as ListPayload | null;

      if (!res.ok) {
        const m = typeof parsed?.error === "string" ? parsed.error : raw.trim() ? raw : `Failed (HTTP ${res.status})`;
        throw new Error(m);
      }
      if (!parsed || parsed.ok !== true) throw new Error(typeof parsed?.error === "string" ? parsed.error : "API did not return ok:true");

      setCycle(parsed.cycle ?? null);
      setDepartments(Array.isArray(parsed.departments) ? parsed.departments : []);
      setKpis(Array.isArray(parsed.kpis) ? parsed.kpis : []);
      if (!parsed.cycle) setMsg("No active cycle. Create/activate a quarterly cycle first, then come back.");
    } catch (e: unknown) {
      setMsg(getErrorMessage(e, "Failed to load KPIs"));
    } finally {
      setLoading(false);
    }
  }

  function resetForm() {
    setForm({
      title: "",
      department_id: departments[0]?.id ?? "",
      current_value: "0",
      target_value: "0",
      weight: "1",
      is_active: true,
      notes: "",
    });
    setCreating(false);
    setEditingId(null);
  }

  async function saveCreate() {
    setMsg(null);
    try {
      const session = await ensureAuth();
      if (!session) return;

      const res = await fetch(`/api/o/${encodeURIComponent(orgSlug)}/kpis`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({
          title: form.title.trim(),
          department_id: form.department_id,
          current_value: Number(form.current_value),
          target_value: Number(form.target_value),
          weight: Number(form.weight),
          is_active: Boolean(form.is_active),
          notes: form.notes.trim() || undefined,
        }),
      });

      const raw = await res.text();
      const parsedUnknown = await safeParseJson(raw);
      const parsed = parsedUnknown as { ok?: boolean; error?: string } | null;

      if (!res.ok || !parsed || parsed.ok !== true) {
        const m = typeof parsed?.error === "string" ? parsed.error : raw.trim() ? raw : "Failed to create KPI";
        throw new Error(m);
      }

      resetForm();
      await load();
    } catch (e: unknown) {
      setMsg(getErrorMessage(e, "Failed to create KPI"));
    }
  }

  function startEdit(k: Kpi) {
    setEditingId(k.id);
    setCreating(true);
    setForm({
      title: k.title,
      department_id: k.department_id,
      current_value: String(k.current_value),
      target_value: String(k.target_value),
      weight: String(k.weight),
      is_active: Boolean(k.is_active),
      notes: "",
    });
  }

  async function saveEdit() {
    if (!editingId) return;
    setMsg(null);

    try {
      const session = await ensureAuth();
      if (!session) return;

      const res = await fetch(`/api/o/${encodeURIComponent(orgSlug)}/kpis/${encodeURIComponent(editingId)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({
          title: form.title.trim(),
          department_id: form.department_id,
          current_value: Number(form.current_value),
          target_value: Number(form.target_value),
          weight: Number(form.weight),
          is_active: Boolean(form.is_active),
          notes: form.notes.trim() || undefined,
        }),
      });

      const raw = await res.text();
      const parsedUnknown = await safeParseJson(raw);
      const parsed = parsedUnknown as { ok?: boolean; error?: string } | null;

      if (!res.ok || !parsed || parsed.ok !== true) {
        const m = typeof parsed?.error === "string" ? parsed.error : raw.trim() ? raw : "Failed to update KPI";
        throw new Error(m);
      }

      resetForm();
      await load();
    } catch (e: unknown) {
      setMsg(getErrorMessage(e, "Failed to update KPI"));
    }
  }

  async function toggleActive(k: Kpi) {
    setMsg(null);
    try {
      const session = await ensureAuth();
      if (!session) return;

      const res = await fetch(`/api/o/${encodeURIComponent(orgSlug)}/kpis/${encodeURIComponent(k.id)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({ is_active: !k.is_active, notes: "toggle active" }),
      });

      const raw = await res.text();
      const parsedUnknown = await safeParseJson(raw);
      const parsed = parsedUnknown as { ok?: boolean; error?: string } | null;

      if (!res.ok || !parsed || parsed.ok !== true) {
        const m = typeof parsed?.error === "string" ? parsed.error : raw.trim() ? raw : "Failed to toggle KPI";
        throw new Error(m);
      }

      await load();
    } catch (e: unknown) {
      setMsg(getErrorMessage(e, "Failed to toggle KPI"));
    }
  }

  async function logout() {
    await supabase.auth.signOut();
    router.replace("/auth");
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orgSlug]);

  useEffect(() => {
    // set default department on first load
    if (!form.department_id && departments.length) {
      setForm((p) => ({ ...p, department_id: departments[0]?.id ?? "" }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [departments.length]);

  if (loading) {
    return (
      <main style={styles.shell}>
        <div style={styles.container}>
          <div style={styles.skeleton} />
        </div>
      </main>
    );
  }

  return (
    <div style={styles.shell}>
      <header style={styles.header}>
        <div style={styles.headerInner}>
          <div style={styles.brand}>
            <span style={styles.brandDot} />
            <span style={styles.brandText}>ALAMIN</span>
          </div>

          <div style={styles.headerRight}>
            <div style={styles.headerMeta}>
              <div style={styles.metaTop}>/o/{orgSlug}/kpis</div>
              {sessionEmail ? <div style={styles.metaBottom}>{sessionEmail}</div> : null}
            </div>

            <button type="button" onClick={() => void load()} style={styles.secondaryBtn}>
              Refresh
            </button>
            <button type="button" onClick={() => router.push(`/o/${encodeURIComponent(orgSlug)}/trends`)} style={styles.secondaryBtn}>
              Trends
            </button>
            <button type="button" onClick={() => void logout()} style={styles.ghostBtn}>
              Logout
            </button>
          </div>
        </div>
      </header>

      <main style={styles.main}>
        <div style={styles.hero}>
          <div>
            <h1 style={styles.h1}>KPIs</h1>
            <p style={styles.p}>Create and manage KPIs for the active cycle.</p>
            <div style={{ ...styles.muted, marginTop: 8 }}>
              {cycle ? `Active: Q${cycle.quarter} ${cycle.year} · ${cycle.status}` : "No active cycle"}
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <button type="button" onClick={() => (creating ? resetForm() : (setCreating(true), setEditingId(null)))} style={styles.primaryBtn}>
              {creating ? "Close" : "New KPI"}
            </button>
          </div>
        </div>

        {msg ? (
          <div style={styles.alert}>
            <div style={styles.alertTitle}>Action needed</div>
            <div style={styles.alertText}>{msg}</div>
          </div>
        ) : null}

        {creating ? (
          <section style={{ ...styles.card, marginTop: 16 }}>
            <div style={styles.cardTitle}>{editingId ? "Edit KPI" : "Create KPI"}</div>

            <div style={styles.formGrid}>
              <label style={styles.label}>
                Title
                <input
                  value={form.title}
                  onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
                  style={styles.input}
                  placeholder="e.g., Revenue Growth"
                />
              </label>

              <label style={styles.label}>
                Department
                <select
                  value={form.department_id}
                  onChange={(e) => setForm((p) => ({ ...p, department_id: e.target.value }))}
                  style={styles.input}
                >
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </label>

              <label style={styles.label}>
                Current value
                <input
                  value={form.current_value}
                  onChange={(e) => setForm((p) => ({ ...p, current_value: e.target.value }))}
                  style={styles.input}
                  inputMode="decimal"
                />
              </label>

              <label style={styles.label}>
                Target value
                <input
                  value={form.target_value}
                  onChange={(e) => setForm((p) => ({ ...p, target_value: e.target.value }))}
                  style={styles.input}
                  inputMode="decimal"
                />
              </label>

              <label style={styles.label}>
                Weight
                <input
                  value={form.weight}
                  onChange={(e) => setForm((p) => ({ ...p, weight: e.target.value }))}
                  style={styles.input}
                  inputMode="decimal"
                />
              </label>

              <label style={styles.label}>
                Active
                <select
                  value={form.is_active ? "true" : "false"}
                  onChange={(e) => setForm((p) => ({ ...p, is_active: e.target.value === "true" }))}
                  style={styles.input}
                >
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </label>

              <label style={{ ...styles.label, gridColumn: "1 / -1" }}>
                Notes (optional)
                <input
                  value={form.notes}
                  onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
                  style={styles.input}
                  placeholder="Saved into kpi_values_history.notes"
                />
              </label>
            </div>

            <div style={{ display: "flex", gap: 10, marginTop: 12, flexWrap: "wrap" }}>
              <button type="button" disabled={!canSubmit || !cycle} onClick={() => void (editingId ? saveEdit() : saveCreate())} style={styles.primaryBtn}>
                {editingId ? "Save changes" : "Create KPI"}
              </button>
              <button type="button" onClick={resetForm} style={styles.secondaryBtn}>
                Cancel
              </button>
            </div>
          </section>
        ) : null}

        <section style={{ ...styles.card, marginTop: 16 }}>
          <div style={styles.cardTitle}>KPI list</div>

          {kpis.length ? (
            <div style={styles.tableWrap}>
              <table style={styles.table}>
                <thead>
                  <tr>
                    <th style={styles.th}>Title</th>
                    <th style={styles.th}>Dept</th>
                    <th style={styles.th}>Current</th>
                    <th style={styles.th}>Target</th>
                    <th style={styles.th}>Weight</th>
                    <th style={styles.th}>Active</th>
                    <th style={styles.th}>Last update</th>
                    <th style={styles.th}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {kpis.map((k) => (
                    <tr key={k.id}>
                      <td style={styles.tdStrong}>{k.title}</td>
                      <td style={styles.td}>{k.department_name ?? "—"}</td>
                      <td style={styles.td}>{Number(k.current_value).toLocaleString()}</td>
                      <td style={styles.td}>{Number(k.target_value).toLocaleString()}</td>
                      <td style={styles.td}>{Number(k.weight).toLocaleString()}</td>
                      <td style={styles.td}>{k.is_active ? "Yes" : "No"}</td>
                      <td style={styles.td}>{fmtDate(k.last_recorded_at)}</td>
                      <td style={styles.td}>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                          <button type="button" onClick={() => startEdit(k)} style={styles.smallBtn}>
                            Edit
                          </button>
                          <button type="button" onClick={() => void toggleActive(k)} style={styles.smallBtn}>
                            {k.is_active ? "Deactivate" : "Activate"}
                          </button>
                          <button type="button" onClick={() => router.push(`/o/${encodeURIComponent(orgSlug)}/trends?kpi=${encodeURIComponent(k.id)}`)} style={styles.smallBtn}>
                            Trend
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div style={styles.muted}>No KPIs for this cycle.</div>
          )}
        </section>
      </main>
    </div>
  );
}

const styles = {
  shell: {
    minHeight: "100vh",
    background:
      "radial-gradient(1000px 600px at 20% 10%, rgba(255,255,255,0.10), transparent 60%), radial-gradient(1000px 600px at 80% 20%, rgba(255,255,255,0.08), transparent 55%), #000",
    color: "white",
  },
  container: { maxWidth: 1100, margin: "0 auto", padding: "40px 18px" },
  skeleton: {
    height: 220,
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.06)",
  },

  header: {
    position: "sticky",
    top: 0,
    zIndex: 20,
    backdropFilter: "blur(14px)",
    background: "rgba(0,0,0,0.65)",
    borderBottom: "1px solid rgba(255,255,255,0.08)",
  },
  headerInner: {
    maxWidth: 1100,
    margin: "0 auto",
    padding: "14px 18px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    flexWrap: "wrap",
  },
  brand: { display: "flex", alignItems: "center", gap: 10 },
  brandDot: {
    width: 10,
    height: 10,
    borderRadius: 999,
    background: "rgba(255,255,255,0.85)",
    boxShadow: "0 0 0 1px rgba(255,255,255,0.15) inset",
  },
  brandText: { fontWeight: 900, letterSpacing: 0.4 },

  headerRight: { display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" as const },
  headerMeta: { textAlign: "right" as const },
  metaTop: { fontSize: 12, color: "rgba(255,255,255,0.7)" },
  metaBottom: { fontSize: 12, color: "rgba(255,255,255,0.55)" },

  secondaryBtn: {
    height: 36,
    padding: "0 12px",
    borderRadius: 999,
    cursor: "pointer",
    fontWeight: 800,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(0,0,0,0.25)",
    color: "rgba(255,255,255,0.9)",
  },
  primaryBtn: {
    height: 36,
    padding: "0 14px",
    borderRadius: 999,
    cursor: "pointer",
    fontWeight: 900,
    border: "1px solid rgba(255,255,255,0.22)",
    background: "rgba(255,255,255,0.10)",
    color: "rgba(255,255,255,0.95)",
  },
  ghostBtn: {
    height: 36,
    padding: "0 12px",
    borderRadius: 999,
    cursor: "pointer",
    fontWeight: 800,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "transparent",
    color: "rgba(255,255,255,0.9)",
  },

  main: { maxWidth: 1100, margin: "0 auto", padding: "34px 18px 60px" },
  hero: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 16,
    flexWrap: "wrap",
  },
  h1: { fontSize: 46, margin: 0, fontWeight: 900 },
  p: { margin: "8px 0 0", color: "rgba(255,255,255,0.65)" },

  alert: {
    marginTop: 16,
    borderRadius: 16,
    border: "1px solid rgba(255,80,80,0.25)",
    background: "rgba(255,80,80,0.10)",
    padding: 14,
  },
  alertTitle: { fontWeight: 900, marginBottom: 6 },
  alertText: { color: "rgba(255,220,220,0.9)", whiteSpace: "pre-wrap" as const },

  card: {
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(255,255,255,0.06)",
    padding: 16,
  },
  cardTitle: { fontWeight: 900, marginBottom: 10 },
  muted: { color: "rgba(255,255,255,0.55)", fontSize: 12 },

  formGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 12,
  },
  label: { display: "grid", gap: 6, fontSize: 12, color: "rgba(255,255,255,0.75)" },
  input: {
    height: 40,
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.14)",
    background: "rgba(0,0,0,0.25)",
    color: "rgba(255,255,255,0.92)",
    padding: "0 12px",
    outline: "none",
  },

  tableWrap: { overflowX: "auto" as const, borderRadius: 14, border: "1px solid rgba(255,255,255,0.10)" },
  table: { width: "100%", borderCollapse: "collapse" as const, minWidth: 860 },
  th: { textAlign: "left" as const, fontSize: 12, color: "rgba(255,255,255,0.65)", padding: "10px 12px", borderBottom: "1px solid rgba(255,255,255,0.10)" },
  td: { padding: "10px 12px", borderBottom: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.85)", fontSize: 13 },
  tdStrong: { padding: "10px 12px", borderBottom: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.95)", fontSize: 13, fontWeight: 900 },
  smallBtn: {
    height: 30,
    padding: "0 10px",
    borderRadius: 999,
    cursor: "pointer",
    fontWeight: 800,
    border: "1px solid rgba(255,255,255,0.16)",
    background: "rgba(0,0,0,0.22)",
    color: "rgba(255,255,255,0.92)",
    fontSize: 12,
  },
} satisfies Record<string, React.CSSProperties>;