"use client";

import { useCallback, useMemo, useState } from "react";

type KPI = {
  id: string;
  title: string;
  weight: number;
  target_value: number;
  current_value: number;
  department_id: string;
  direction: "increase" | "decrease";
  is_active: boolean;
};

type Department = {
  id: string;
  name: string;
};

type ApiError = { error: string; detail?: string; ok?: boolean };

type KpisOk = { kpis: KPI[]; ok?: boolean };
type DepsOk = { departments: Department[]; ok?: boolean };

type KpisApiResponse = KpisOk | ApiError;
type DepartmentsApiResponse = DepsOk | ApiError;

function isApiError(x: unknown): x is ApiError {
  if (!x || typeof x !== "object") return false;
  return "error" in x && typeof (x as { error?: unknown }).error === "string";
}

function safeErrorMessage(x: unknown, fallback: string) {
  if (x instanceof Error && x.message) return x.message;
  if (typeof x === "string" && x.trim()) return x;
  return fallback;
}

async function safeJson<T>(res: Response): Promise<T | null> {
  try {
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

export default function KPIsPage({ params }: { params: { slug: string } }) {
  const { slug } = params;

  const [kpis, setKpis] = useState<KPI[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadedOnce, setLoadedOnce] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    title: "",
    department_id: "",
    target_value: 0,
    weight: 1,
    direction: "increase" as "increase" | "decrease",
  });

  const deptNameById = useMemo(() => {
    const m = new Map<string, string>();
    for (const d of departments) m.set(d.id, d.name);
    return m;
  }, [departments]);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const [kpiRes, depRes] = await Promise.all([
        fetch(`/api/o/${slug}/kpis`, { cache: "no-store" }),
        fetch(`/api/o/${slug}/departments`, { cache: "no-store" }),
      ]);

      const kpiJson = await safeJson<KpisApiResponse>(kpiRes);
      const depJson = await safeJson<DepartmentsApiResponse>(depRes);

      if (!kpiRes.ok) {
        const msg =
          (kpiJson && isApiError(kpiJson) && kpiJson.error) ||
          `Failed to load KPIs (${kpiRes.status})`;
        throw new Error(msg);
      }
      if (!depRes.ok) {
        const msg =
          (depJson && isApiError(depJson) && depJson.error) ||
          `Failed to load departments (${depRes.status})`;
        throw new Error(msg);
      }

      const nextKpis =
        kpiJson && !isApiError(kpiJson) && Array.isArray(kpiJson.kpis)
          ? kpiJson.kpis
          : [];

      const nextDeps =
        depJson && !isApiError(depJson) && Array.isArray(depJson.departments)
          ? depJson.departments
          : [];

      setKpis(nextKpis);
      setDepartments(nextDeps);
      setLoadedOnce(true);
    } catch (e: unknown) {
      setError(safeErrorMessage(e, "Something went wrong"));
      setLoadedOnce(true);
    } finally {
      setLoading(false);
    }
  }, [slug]);

  async function createKPI() {
    setError(null);

    if (!form.title.trim()) {
      setError("Title is required");
      return;
    }
    if (!form.department_id) {
      setError("Department is required");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`/api/o/${slug}/kpis`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const json = await safeJson<ApiError>(res);

      if (!res.ok) {
        const msg =
          (json && isApiError(json) && json.error) || "Failed to create KPI";
        throw new Error(msg);
      }

      setForm({
        title: "",
        department_id: "",
        target_value: 0,
        weight: 1,
        direction: "increase",
      });

      await loadData();
    } catch (e: unknown) {
      setError(safeErrorMessage(e, "Failed to create KPI"));
    } finally {
      setLoading(false);
    }
  }

  async function toggleActive(id: string, is_active: boolean) {
    setError(null);
    setLoading(true);

    try {
      const res = await fetch(`/api/o/${slug}/kpis/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_active: !is_active }),
      });

      const json = await safeJson<ApiError>(res);

      if (!res.ok) {
        const msg =
          (json && isApiError(json) && json.error) || "Failed to update KPI";
        throw new Error(msg);
      }

      await loadData();
    } catch (e: unknown) {
      setError(safeErrorMessage(e, "Failed to update KPI"));
    } finally {
      setLoading(false);
    }
  }

  async function deleteKPI(id: string) {
    setError(null);
    setLoading(true);

    try {
      const res = await fetch(`/api/o/${slug}/kpis/${id}`, { method: "DELETE" });
      const json = await safeJson<ApiError>(res);

      if (!res.ok) {
        const msg =
          (json && isApiError(json) && json.error) || "Failed to delete KPI";
        throw new Error(msg);
      }

      await loadData();
    } catch (e: unknown) {
      setError(safeErrorMessage(e, "Failed to delete KPI"));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="p-10 space-y-8">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">KPI Management</h1>

        <button
          onClick={loadData}
          className="border px-3 py-2 rounded"
          disabled={loading}
        >
          {loadedOnce ? "Refresh" : "Load KPIs"}
        </button>
      </div>

      {error ? (
        <div className="border border-red-300 bg-red-50 text-red-800 p-3 rounded">
          {error}
        </div>
      ) : null}

      {!loadedOnce ? (
        <div className="border p-6 rounded-lg text-gray-600">
          Click <span className="font-semibold">Load KPIs</span> to fetch KPIs
          and departments.
        </div>
      ) : null}

      {loading && loadedOnce ? (
        <div className="p-2 text-gray-600">Loading...</div>
      ) : null}

      <div className="border p-6 rounded-lg space-y-4">
        <h2 className="font-semibold">Create KPI</h2>

        <input
          placeholder="KPI Title"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
          className="border p-2 w-full rounded"
        />

        <select
          value={form.department_id}
          onChange={(e) =>
            setForm({ ...form, department_id: e.target.value })
          }
          className="border p-2 w-full rounded"
        >
          <option value="">Select Department</option>
          {departments.map((d) => (
            <option key={d.id} value={d.id}>
              {d.name}
            </option>
          ))}
        </select>

        <input
          type="number"
          placeholder="Target Value"
          value={form.target_value}
          onChange={(e) =>
            setForm({ ...form, target_value: Number(e.target.value) })
          }
          className="border p-2 w-full rounded"
        />

        <input
          type="number"
          placeholder="Weight"
          value={form.weight}
          onChange={(e) =>
            setForm({ ...form, weight: Number(e.target.value) })
          }
          className="border p-2 w-full rounded"
        />

        <select
          value={form.direction}
          onChange={(e) =>
            setForm({
              ...form,
              direction: e.target.value as "increase" | "decrease",
            })
          }
          className="border p-2 w-full rounded"
        >
          <option value="increase">Increase</option>
          <option value="decrease">Decrease</option>
        </select>

        <button
          onClick={createKPI}
          className="bg-black text-white px-4 py-2 rounded"
          disabled={loading}
        >
          Create KPI
        </button>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-3 text-left">KPI</th>
              <th className="p-3 text-left">Department</th>
              <th className="p-3 text-left">Target</th>
              <th className="p-3 text-left">Weight</th>
              <th className="p-3 text-left">Direction</th>
              <th className="p-3 text-left">Status</th>
              <th className="p-3 text-right"></th>
            </tr>
          </thead>

          <tbody>
            {kpis.map((kpi) => (
              <tr key={kpi.id} className="border-t">
                <td className="p-3">{kpi.title}</td>
                <td className="p-3">
                  {deptNameById.get(kpi.department_id) || "—"}
                </td>
                <td className="p-3">{kpi.target_value}</td>
                <td className="p-3">{kpi.weight}</td>
                <td className="p-3">{kpi.direction}</td>
                <td className="p-3">{kpi.is_active ? "Active" : "Inactive"}</td>

                <td className="p-3 text-right space-x-3">
                  <button
                    onClick={() => toggleActive(kpi.id, kpi.is_active)}
                    className="text-blue-600"
                    disabled={loading}
                  >
                    Toggle
                  </button>

                  <button
                    onClick={() => deleteKPI(kpi.id)}
                    className="text-red-600"
                    disabled={loading}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}

            {loadedOnce && kpis.length === 0 ? (
              <tr>
                <td className="p-6 text-gray-500" colSpan={8}>
                  No KPIs yet.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}