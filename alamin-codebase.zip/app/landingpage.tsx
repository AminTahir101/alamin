// app/landingpage.tsx
"use client";

import Link from "next/link";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Top nav */}
      <header className="sticky top-0 z-20 border-b border-white/10 bg-black/60 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight">
            <span className="inline-block h-3 w-3 rounded bg-white" />
            ALAMIN
          </Link>

          <nav className="hidden items-center gap-6 text-sm text-white/70 md:flex">
            <a href="#features" className="hover:text-white">
              Features
            </a>
            <a href="#security" className="hover:text-white">
              Security
            </a>
            <a href="#pricing" className="hover:text-white">
              Pricing
            </a>
          </nav>

          <div className="flex items-center gap-3">
            <Link
              href="/auth"
              className="rounded-full border border-white/15 px-4 py-2 text-sm font-medium text-white/90 hover:bg-white/5"
            >
              Log in
            </Link>
            <Link
              href="/auth"
              className="rounded-full bg-white px-4 py-2 text-sm font-semibold text-black hover:bg-white/90"
            >
              Sign up
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <main>
        <section className="mx-auto max-w-6xl px-6 pt-20 pb-14">
          <div className="grid items-center gap-10 md:grid-cols-2">
            <div>
              <p className="inline-flex items-center rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/70">
                AI Performance Intelligence for B2B
              </p>

              <h1 className="mt-5 text-4xl font-semibold leading-tight tracking-tight md:text-5xl">
                Turn human KPI input into{" "}
                <span className="text-white/70">OKRs, JTBD, and evaluations</span>—automatically.
              </h1>

              <p className="mt-5 max-w-xl text-base leading-7 text-white/70">
                ALAMIN helps teams define the right goals, generate measurable OKRs, map Jobs-To-Be-Done,
                and track performance with AI—without spreadsheets and manual overhead.
              </p>

              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Link
                  href="/auth"
                  className="inline-flex h-12 items-center justify-center rounded-full bg-white px-6 text-sm font-semibold text-black hover:bg-white/90"
                >
                  Get started
                </Link>

                <a
                  href="#features"
                  className="inline-flex h-12 items-center justify-center rounded-full border border-white/15 px-6 text-sm font-semibold text-white/90 hover:bg-white/5"
                >
                  See features
                </a>
              </div>

              <div className="mt-6 text-xs text-white/50">
                No credit card. Create an org after signup.
              </div>
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/5 p-5 shadow-[0_30px_80px_rgba(0,0,0,0.6)]">
              <div className="rounded-xl border border-white/10 bg-black/40 p-4">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-semibold">Example output</div>
                  <div className="text-xs text-white/50">Auto-generated</div>
                </div>

                <div className="mt-4 grid gap-3 text-sm">
                  <div className="rounded-lg border border-white/10 bg-black/40 p-3">
                    <div className="text-white/70">Objective</div>
                    <div className="mt-1 font-semibold">
                      Improve customer onboarding conversion
                    </div>
                  </div>

                  <div className="rounded-lg border border-white/10 bg-black/40 p-3">
                    <div className="text-white/70">Key Results</div>
                    <ul className="mt-2 list-disc space-y-1 pl-5 text-white/80">
                      <li>Increase activation rate from 42% → 55%</li>
                      <li>Reduce time-to-first-value from 3d → 1d</li>
                      <li>Cut onboarding drop-offs by 25%</li>
                    </ul>
                  </div>

                  <div className="rounded-lg border border-white/10 bg-black/40 p-3">
                    <div className="text-white/70">JTBD</div>
                    <div className="mt-1 text-white/80">
                      “When I start using the platform, I want guidance and clarity, so I can reach
                      value quickly without help.”
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 rounded-xl border border-white/10 bg-black/40 p-4 text-xs text-white/60">
                Connect KPIs → generate OKRs → track performance → evaluate teams.
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section id="features" className="mx-auto max-w-6xl px-6 py-14">
          <h2 className="text-2xl font-semibold tracking-tight">Features</h2>
          <p className="mt-2 max-w-2xl text-white/70">
            Everything you need to run goal-setting and performance management for your company with minimal overhead.
          </p>

          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <FeatureCard
              title="KPI → OKR generator"
              desc="Input your KPI context. Get structured objectives and measurable key results."
            />
            <FeatureCard
              title="JTBD auto-mapping"
              desc="Turn customer and internal needs into clear JTBD statements and outcomes."
            />
            <FeatureCard
              title="Evaluation & scoring"
              desc="Compare planned vs actual. Generate summaries, insights, and actions."
            />
            <FeatureCard
              title="Multi-tenant orgs"
              desc="Create organizations and route to /o/[slug]/dashboard."
            />
            <FeatureCard
              title="Role-ready foundations"
              desc="Built to support maker/checker, managers, and exec reporting later."
            />
            <FeatureCard
              title="Security first"
              desc="Designed to work with Supabase RLS and tenant-safe data patterns."
            />
          </div>
        </section>

        {/* Security */}
        <section id="security" className="mx-auto max-w-6xl px-6 py-14">
          <div className="rounded-2xl border border-white/10 bg-white/5 p-8">
            <h2 className="text-2xl font-semibold tracking-tight">Security</h2>
            <p className="mt-2 max-w-3xl text-white/70">
              Built for B2B: tenant isolation, Supabase RLS compatibility, and safe client-side auth.
              Never put service_role keys in the browser.
            </p>
          </div>
        </section>

        {/* Pricing */}
        <section id="pricing" className="mx-auto max-w-6xl px-6 pt-14 pb-20">
          <h2 className="text-2xl font-semibold tracking-tight">Pricing</h2>
          <p className="mt-2 text-white/70">Simple tiers. Start free, upgrade when ready.</p>

          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <PriceCard title="Starter" price="Free" bullets={["1 org", "Core OKR generation", "Basic dashboards"]} />
            <PriceCard
              title="Pro"
              price="$29/mo"
              bullets={["Unlimited orgs", "Advanced evaluation", "Exports & integrations (soon)"]}
              highlight
            />
            <PriceCard title="Enterprise" price="Let’s talk" bullets={["SLA", "Custom controls", "On-prem / VPC (optional)"]} />
          </div>

          <div className="mt-10 flex justify-center">
            <Link
              href="/auth"
              className="inline-flex h-12 items-center justify-center rounded-full bg-white px-7 text-sm font-semibold text-black hover:bg-white/90"
            >
              Start now
            </Link>
          </div>
        </section>

        <footer className="border-t border-white/10 py-10">
          <div className="mx-auto flex max-w-6xl flex-col gap-3 px-6 text-sm text-white/60 md:flex-row md:items-center md:justify-between">
            <div>© {new Date().getFullYear()} ALAMIN</div>
            <div className="flex gap-5">
              <Link href="/auth" className="hover:text-white">
                Login
              </Link>
              <a href="#features" className="hover:text-white">
                Features
              </a>
              <a href="#pricing" className="hover:text-white">
                Pricing
              </a>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}

function FeatureCard({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
      <div className="text-base font-semibold">{title}</div>
      <div className="mt-2 text-sm leading-6 text-white/70">{desc}</div>
    </div>
  );
}

function PriceCard({
  title,
  price,
  bullets,
  highlight,
}: {
  title: string;
  price: string;
  bullets: string[];
  highlight?: boolean;
}) {
  return (
    <div
      className={[
        "rounded-2xl border p-6",
        highlight ? "border-white/25 bg-white/10" : "border-white/10 bg-white/5",
      ].join(" ")}
    >
      <div className="text-base font-semibold">{title}</div>
      <div className="mt-3 text-3xl font-semibold tracking-tight">{price}</div>
      <ul className="mt-5 list-disc space-y-2 pl-5 text-sm text-white/70">
        {bullets.map((b) => (
          <li key={b}>{b}</li>
        ))}
      </ul>

      <div className="mt-6">
        <Link
          href="/auth"
          className={[
            "inline-flex h-11 w-full items-center justify-center rounded-full text-sm font-semibold",
            highlight ? "bg-white text-black hover:bg-white/90" : "border border-white/15 text-white hover:bg-white/5",
          ].join(" ")}
        >
          {title === "Enterprise" ? "Contact sales" : "Choose"}
        </Link>
      </div>
    </div>
  );
}