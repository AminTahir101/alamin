"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";
import type { AuthChangeEvent, Session } from "@supabase/supabase-js";

type Org = {
  id: string;
  slug: string;
  name: string;
};

function getErrorMessage(err: unknown, fallback: string) {
  if (err instanceof Error) return err.message;
  if (typeof err === "string") return err;

  if (err && typeof err === "object") {
    const maybe = err as { message?: unknown; error_description?: unknown; error?: unknown };
    if (typeof maybe.message === "string" && maybe.message.trim()) return maybe.message;
    if (typeof maybe.error_description === "string" && maybe.error_description.trim()) {
      return maybe.error_description;
    }
    if (typeof maybe.error === "string" && maybe.error.trim()) return maybe.error;
  }

  return fallback;
}

async function safeParseJson(text: string): Promise<unknown> {
  if (!text.trim()) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

async function waitForSession(timeoutMs = 4000): Promise<Session | null> {
  const first = await supabase.auth.getSession();
  if (first.data.session) return first.data.session;

  return await new Promise<Session | null>((resolve) => {
    let unsub: (() => void) | null = null;

    const timer = setTimeout(() => {
      if (unsub) unsub();
      resolve(null);
    }, timeoutMs);

    const { data } = supabase.auth.onAuthStateChange(
      (_event: AuthChangeEvent, session: Session | null) => {
        if (session) {
          clearTimeout(timer);
          if (unsub) unsub();
          resolve(session);
        }
      }
    );

    unsub = () => data.subscription.unsubscribe();
  });
}

function normalizeSlug(input: string) {
  return input
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-_]/g, "")
    .replace(/-+/g, "-");
}

function rememberOrgSlug(slug: string) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem("last_org_slug", slug);
  } catch {
    // ignore
  }
}

function readLastOrgSlug() {
  if (typeof window === "undefined") return "";
  try {
    return localStorage.getItem("last_org_slug")?.trim() ?? "";
  } catch {
    return "";
  }
}

async function fetchUserOrgs(accessToken: string): Promise<Org[]> {
  const res = await fetch("/api/auth/orgs", {
    method: "GET",
    headers: { Authorization: `Bearer ${accessToken}` },
    cache: "no-store",
  });

  const raw = await res.text();
  const parsed = (await safeParseJson(raw)) as
    | { ok?: boolean; orgs?: Org[]; error?: string }
    | null;

  if (!res.ok || !parsed || parsed.ok !== true) {
    throw new Error(parsed?.error || raw || "Failed to load organizations");
  }

  return Array.isArray(parsed.orgs) ? parsed.orgs : [];
}

export default function AuthPage() {
  const router = useRouter();

  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [booting, setBooting] = useState(true);
  const [resolvingTenant, setResolvingTenant] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const [orgs, setOrgs] = useState<Org[]>([]);
  const [showOrgPicker, setShowOrgPicker] = useState(false);

  const [newOrgSlug, setNewOrgSlug] = useState("");
  const [newOrgName, setNewOrgName] = useState("");

  const envHint = useMemo(() => {
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
    const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";
    return {
      url,
      key,
      looksLikeJwt: key.startsWith("eyJ"),
      looksLikePublishable: key.startsWith("sb_publishable_"),
    };
  }, []);

  const resolveTenantAndRoute = useCallback(
    async (session: Session) => {
      setResolvingTenant(true);
      setMsg(null);

      try {
        const availableOrgs = await fetchUserOrgs(session.access_token);
        setOrgs(availableOrgs);

        const lastSlug = readLastOrgSlug();
        const remembered = availableOrgs.find((o) => o.slug === lastSlug);

        if (remembered) {
          router.replace(`/o/${encodeURIComponent(remembered.slug)}/dashboard`);
          return;
        }

        if (availableOrgs.length === 1) {
          rememberOrgSlug(availableOrgs[0].slug);
          router.replace(`/o/${encodeURIComponent(availableOrgs[0].slug)}/dashboard`);
          return;
        }

        if (availableOrgs.length > 1) {
          setShowOrgPicker(true);
          return;
        }

        setShowOrgPicker(false);
        setMsg(
          "No organization membership was found for this account yet. Create a workspace slug below to continue onboarding."
        );
      } catch (err: unknown) {
        setMsg(getErrorMessage(err, "Failed to resolve workspace"));
      } finally {
        setResolvingTenant(false);
      }
    },
    [router]
  );

  useEffect(() => {
    async function boot() {
      try {
        const { data } = await supabase.auth.getSession();
        if (data.session) {
          await resolveTenantAndRoute(data.session);
        }
      } finally {
        setBooting(false);
      }
    }

    void boot();
  }, [resolveTenantAndRoute]);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMsg(null);

    const cleanEmail = email.trim();
    if (!cleanEmail) return setMsg("Email is required.");
    if (!password) return setMsg("Password is required.");

    if (!envHint.url || !envHint.key) {
      setMsg("Supabase env is missing. Check .env.local and restart npm run dev.");
      return;
    }

    if (envHint.looksLikePublishable) {
      setMsg(
        "Your NEXT_PUBLIC_SUPABASE_ANON_KEY is wrong. Use the public ANON JWT key that starts with eyJ, then restart the dev server."
      );
      return;
    }

    setLoading(true);

    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email: cleanEmail,
          password,
        });
        if (error) throw error;

        const session = await waitForSession(3500);
        if (session) {
          await resolveTenantAndRoute(session);
        } else {
          setMsg("Account created. If email confirmation is enabled, confirm your email and then log in.");
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password,
        });
        if (error) throw error;

        const session = await waitForSession(3500);
        if (session) {
          await resolveTenantAndRoute(session);
        } else {
          setMsg("Login succeeded but the session was not established. Try again.");
        }
      }
    } catch (err: unknown) {
      const m = getErrorMessage(err, "Something went wrong");

      if (m.toLowerCase().includes("failed to fetch")) {
        setMsg(
          "Failed to reach Supabase.\n\n1) Use the ANON JWT key that starts with eyJ.\n2) Restart dev server after editing .env.local.\n3) Disable privacy extensions on localhost.\n4) Ensure NEXT_PUBLIC_SUPABASE_URL is exactly https://<project>.supabase.co"
        );
      } else {
        setMsg(m);
      }
    } finally {
      setLoading(false);
    }
  }

  function selectOrg(slug: string) {
    rememberOrgSlug(slug);
    router.replace(`/o/${encodeURIComponent(slug)}/dashboard`);
  }

  function goToCreateWorkspace() {
    const slug = normalizeSlug(newOrgSlug || newOrgName);
    if (!slug) {
      setMsg("Enter a valid workspace slug or company name.");
      return;
    }

    rememberOrgSlug(slug);
    router.replace(`/o/${encodeURIComponent(slug)}/onboarding`);
  }

  async function logout() {
    await supabase.auth.signOut();
    setShowOrgPicker(false);
    setOrgs([]);
    setMsg(null);
    setEmail("");
    setPassword("");
  }

  if (booting) {
    return (
      <div className="min-h-screen bg-[radial-gradient(900px_520px_at_10%_0%,rgba(255,255,255,0.10),transparent_55%),radial-gradient(900px_520px_at_90%_10%,rgba(255,255,255,0.06),transparent_50%),linear-gradient(180deg,#070707_0%,#030303_100%)] text-white">
        <div className="mx-auto flex min-h-screen max-w-7xl items-center justify-center px-6">
          <div className="h-28 w-full max-w-md animate-pulse rounded-3xl border border-white/10 bg-white/5" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[radial-gradient(1000px_600px_at_8%_0%,rgba(255,255,255,0.12),transparent_55%),radial-gradient(900px_600px_at_92%_10%,rgba(255,255,255,0.06),transparent_50%),linear-gradient(180deg,#080808_0%,#030303_100%)] text-white">
      <header className="border-b border-white/8 bg-black/20 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-6 py-4">
          <Link href="/" className="flex items-center gap-3">
            <span className="h-9 w-9 rounded-xl border border-white/15 bg-linear-to-br from-white/90 to-white/10" />
            <span className="text-lg font-black tracking-[0.05em]">ALAMIN</span>
          </Link>

          <nav className="hidden items-center gap-6 md:flex">
            <Link href="/#features" className="text-sm text-white/65 transition hover:text-white">
              Features
            </Link>
            <Link href="/#security" className="text-sm text-white/65 transition hover:text-white">
              Security
            </Link>
            <Link href="/#pricing" className="text-sm text-white/65 transition hover:text-white">
              Pricing
            </Link>
          </nav>
        </div>
      </header>

      <main className="mx-auto grid min-h-[calc(100vh-74px)] max-w-7xl gap-8 px-6 py-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
        <section className="max-w-2xl">
          <div className="inline-flex items-center rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs font-semibold uppercase tracking-[0.16em] text-white/65">
            AI Performance Intelligence
          </div>

          <h1 className="mt-6 text-5xl font-black tracking-[-0.04em] text-white md:text-6xl">
            Manage company performance without the usual mess.
          </h1>

          <p className="mt-5 max-w-xl text-base leading-8 text-white/60">
            ALAMIN helps companies structure KPIs, track health, compare departments, and prepare for AI-driven insights on top of a clean multi-tenant workspace.
          </p>

          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="text-2xl font-black text-white">Multi-tenant</div>
              <div className="mt-2 text-sm text-white/55">Each user lands in the correct workspace.</div>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="text-2xl font-black text-white">KPI-first</div>
              <div className="mt-2 text-sm text-white/55">Track performance with clean operational control.</div>
            </div>
            <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
              <div className="text-2xl font-black text-white">AI-ready</div>
              <div className="mt-2 text-sm text-white/55">Prepared for summaries, risks, OKRs, and actions.</div>
            </div>
          </div>
        </section>

        <section className="w-full">
          <div className="rounded-[28px] border border-white/10 bg-white/5 p-6 shadow-2xl backdrop-blur-xl md:p-7">
            {showOrgPicker ? (
              <>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-[0.16em] text-white/40">
                      Workspace selection
                    </div>
                    <h2 className="mt-2 text-3xl font-black tracking-[-0.03em] text-white">
                      Choose your company
                    </h2>
                    <p className="mt-3 text-sm leading-6 text-white/58">
                      This account belongs to multiple organizations. Pick the workspace you want to enter.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => void logout()}
                    className="rounded-2xl border border-white/12 bg-white/5 px-4 py-2 text-sm font-semibold text-white/75 transition hover:bg-white/10 hover:text-white"
                  >
                    Logout
                  </button>
                </div>

                <div className="mt-6 space-y-3">
                  {orgs.map((org) => (
                    <button
                      key={org.id}
                      type="button"
                      onClick={() => selectOrg(org.slug)}
                      className="flex w-full items-center justify-between rounded-3xl border border-white/10 bg-black/20 px-5 py-4 text-left transition hover:border-white/18 hover:bg-white/5"
                    >
                      <div>
                        <div className="text-base font-bold text-white">{org.name}</div>
                        <div className="mt-1 text-sm text-white/45">/{org.slug}</div>
                      </div>
                      <span className="text-sm font-semibold text-white/60">Open</span>
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-[0.16em] text-white/40">
                      Secure access
                    </div>
                    <h2 className="mt-2 text-3xl font-black tracking-[-0.03em] text-white">
                      {mode === "login" ? "Welcome back" : "Create your account"}
                    </h2>
                    <p className="mt-3 text-sm leading-6 text-white/58">
                      {mode === "login"
                        ? "Log in to access your workspace."
                        : "Create an account, then continue to your company workspace."}
                    </p>
                  </div>
                </div>

                <div className="mt-6 inline-flex rounded-2xl border border-white/10 bg-black/20 p-1">
                  <button
                    type="button"
                    onClick={() => setMode("login")}
                    disabled={loading || resolvingTenant}
                    className={`rounded-2xl px-4 py-2 text-sm font-semibold transition ${
                      mode === "login"
                        ? "bg-white text-black"
                        : "text-white/70 hover:text-white"
                    }`}
                  >
                    Login
                  </button>
                  <button
                    type="button"
                    onClick={() => setMode("signup")}
                    disabled={loading || resolvingTenant}
                    className={`rounded-2xl px-4 py-2 text-sm font-semibold transition ${
                      mode === "signup"
                        ? "bg-white text-black"
                        : "text-white/70 hover:text-white"
                    }`}
                  >
                    Sign up
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="mt-6 grid gap-4">
                  <div className="grid gap-2">
                    <label className="text-sm font-medium text-white/70">Email</label>
                    <input
                      placeholder="name@company.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      type="email"
                      autoComplete="email"
                      required
                      className="h-12 rounded-2xl border border-white/10 bg-black/20 px-4 text-white outline-none placeholder:text-white/25 focus:border-white/20"
                    />
                  </div>

                  <div className="grid gap-2">
                    <label className="text-sm font-medium text-white/70">Password</label>
                    <input
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      type="password"
                      autoComplete={mode === "login" ? "current-password" : "new-password"}
                      required
                      className="h-12 rounded-2xl border border-white/10 bg-black/20 px-4 text-white outline-none placeholder:text-white/25 focus:border-white/20"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading || resolvingTenant}
                    className="mt-2 h-12 rounded-2xl bg-white text-sm font-black text-black transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {loading || resolvingTenant
                      ? "Please wait..."
                      : mode === "login"
                        ? "Login"
                        : "Create account"}
                  </button>
                </form>

                {msg ? (
                  <div className="mt-5 rounded-2xl border border-red-400/20 bg-red-400/10 px-4 py-3 text-sm whitespace-pre-wrap text-red-100">
                    {msg}
                  </div>
                ) : null}

                {!resolvingTenant && !loading && msg?.toLowerCase().includes("no organization membership") ? (
                  <div className="mt-6 rounded-3xl border border-white/10 bg-black/20 p-5">
                    <div className="text-sm font-semibold text-white">Create a workspace</div>
                    <div className="mt-2 text-sm leading-6 text-white/55">
                      No company is linked to this account yet. Continue onboarding with a new workspace slug.
                    </div>

                    <div className="mt-4 grid gap-3">
                      <input
                        value={newOrgName}
                        onChange={(e) => setNewOrgName(e.target.value)}
                        placeholder="Company name"
                        className="h-11 rounded-2xl border border-white/10 bg-black/20 px-4 text-white outline-none placeholder:text-white/25"
                      />
                      <input
                        value={newOrgSlug}
                        onChange={(e) => setNewOrgSlug(normalizeSlug(e.target.value))}
                        placeholder="workspace-slug"
                        className="h-11 rounded-2xl border border-white/10 bg-black/20 px-4 text-white outline-none placeholder:text-white/25"
                      />
                      <button
                        type="button"
                        onClick={goToCreateWorkspace}
                        className="h-11 rounded-2xl border border-white/12 bg-white/10 text-sm font-bold text-white transition hover:bg-white/15"
                      >
                        Continue to onboarding
                      </button>
                    </div>
                  </div>
                ) : null}
              </>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}