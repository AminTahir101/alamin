"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams, usePathname, useRouter } from "next/navigation";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabaseClient";
import { AppPageHeader, AppShell } from "@/components/app/AppShell";
import SectionCard from "@/components/ui/SectionCard";

type OnboardingBody = {
  companyName: string;
  orgSlug: string;
  year: number;
  quarter: number;
  departments: Array<{ name: string }>;
  kpis: Array<{
    title: string;
    departmentName: string;
    unit: string;
    target: number;
    current: number;
  }>;
};

type ApiOk = { ok: true };
type ApiErr = { ok?: false; error?: string };
type ApiResponse = ApiOk | ApiErr;

function getErrorMessage(err: unknown, fallback: string) {
  if (err instanceof Error) return err.message;
  if (typeof err === "string") return err;
  return fallback;
}

async function safeParseJson(text: string): Promise<unknown> {
  if (!text.trim()) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function toNumber(x: string, fallback: number) {
  const n = Number(x);
  return Number.isFinite(n) ? n : fallback;
}

function slugFromPathname(pathname: string | null): string {
  const p = String(pathname ?? "").trim();
  const parts = p.split("/").filter(Boolean);
  const oIdx = parts.indexOf("o");
  if (oIdx === -1) return "";
  return String(parts[oIdx + 1] ?? "").trim();
}

export default function OnboardingPage() {
  const params = useParams<{ slug?: string }>();
  const pathname = usePathname();
  const router = useRouter();

  const derivedSlug = slugFromPathname(pathname);
  const orgSlug = String(params?.slug ?? derivedSlug ?? "").trim();

  const [sessionEmail, setSessionEmail] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [okMsg, setOkMsg] = useState<string | null>(null);

  const [companyName, setCompanyName] = useState("Jahzeen");
  const now = new Date();
  const [year, setYear] = useState<number>(now.getFullYear());
  const [quarter, setQuarter] = useState<number>(Math.max(1, Math.min(4, Math.floor(now.getMonth() / 3) + 1)));

  const [departments, setDepartments] = useState<Array<{ name: string }>>([
    { name: "Operations" },
    { name: "Sales" },
    { name: "Delivery" },
  ]);

  const [kpis, setKpis] = useState<
    Array<{ title: string; departmentName: string; unit: string; target: string; current: string }>
  >([
    { title: "Bookings per week", departmentName: "Sales", unit: "count", target: "40", current: "10" },
    { title: "On-time delivery rate", departmentName: "Delivery", unit: "%", target: "95", current: "82" },
    { title: "Customer NPS", departmentName: "Operations", unit: "score", target: "60", current: "40" },
  ]);

  const canSubmit = useMemo(() => {
    if (!orgSlug) return false;
    if (!companyName.trim()) return false;
    if (!(year >= 2000 && year <= 2100)) return false;
    if (!(quarter >= 1 && quarter <= 4)) return false;
    if (!departments.length || !kpis.length) return false;

    const deptSet = new Set(departments.map((d) => d.name.trim().toLowerCase()).filter(Boolean));
    if (!deptSet.size) return false;

    for (const k of kpis) {
      if (!k.title.trim()) return false;
      if (!k.departmentName.trim()) return false;
      if (!k.unit.trim()) return false;
      if (!Number.isFinite(Number(k.target))) return false;
      if (!Number.isFinite(Number(k.current))) return false;
      if (!deptSet.has(k.departmentName.trim().toLowerCase())) return false;
    }

    return true;
  }, [companyName, departments, kpis, orgSlug, quarter, year]);

  const ensureAuth = useCallback(async (): Promise<Session | null> => {
    const { data } = await supabase.auth.getSession();
    const session = data.session;
    setSessionEmail(session?.user?.email ?? null);

    if (!session) {
      router.replace("/auth");
      return null;
    }
    return session;
  }, [router]);

  useEffect(() => {
    async function boot() {
      setMsg(null);
      setOkMsg(null);

      try {
        setLoading(true);
        if (!orgSlug) {
          setMsg("slug is required");
          return;
        }

        const session = await ensureAuth();
        if (!session) return;
      } catch (e: unknown) {
        setMsg(getErrorMessage(e, "Failed to load onboarding"));
      } finally {
        setLoading(false);
      }
    }

    void boot();
  }, [ensureAuth, orgSlug]);

  function addDepartment() {
    setDepartments((prev) => [...prev, { name: "" }]);
  }

  function removeDepartment(i: number) {
    setDepartments((prev) => prev.filter((_, idx) => idx !== i));
  }

  function addKpi() {
    const dept = departments[0]?.name || "";
    setKpis((prev) => [...prev, { title: "", departmentName: dept, unit: "count", target: "0", current: "0" }]);
  }

  function removeKpi(i: number) {
    setKpis((prev) => prev.filter((_, idx) => idx !== i));
  }

  async function submit() {
    setMsg(null);
    setOkMsg(null);
    setSaving(true);

    try {
      const session = await ensureAuth();
      if (!session) return;

      const body: OnboardingBody = {
        companyName: companyName.trim(),
        orgSlug,
        year,
        quarter,
        departments: departments.map((d) => ({ name: d.name.trim() })).filter((d) => d.name),
        kpis: kpis.map((k) => ({
          title: k.title.trim(),
          departmentName: k.departmentName.trim(),
          unit: k.unit.trim(),
          target: Number(k.target),
          current: Number(k.current),
        })),
      };

      const apiUrl = new URL(`/api/o/${encodeURIComponent(orgSlug)}/onboarding`, window.location.origin).toString();

      const res = await fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify(body),
        cache: "no-store",
      });

      const raw = await res.text();
      const parsed = (await safeParseJson(raw)) as ApiResponse | null;

      if (!res.ok || !parsed || parsed.ok !== true) {
        throw new Error((parsed as ApiErr | null)?.error || raw || `Failed (HTTP ${res.status})`);
      }

      setOkMsg("Onboarding saved. Redirecting to dashboard...");
      setTimeout(() => router.push(`/o/${encodeURIComponent(orgSlug)}/dashboard`), 300);
    } catch (e: unknown) {
      setMsg(getErrorMessage(e, "Failed to submit onboarding"));
    } finally {
      setSaving(false);
    }
  }

  return (
    <AppShell slug={orgSlug} sessionEmail={sessionEmail}>
      <AppPageHeader
        eyebrow="Workspace setup"
        title="Onboarding"
        description="Create the initial structure for this organization: cycle, departments, and core KPIs. This seeds the rest of the product."
      />

      {msg ? (
        <div className="mb-6 rounded-[20px] border border-red-400/20 bg-red-400/8 px-5 py-4 text-sm text-red-100">
          {msg}
        </div>
      ) : null}

      {okMsg ? (
        <div className="mb-6 rounded-[20px] border border-emerald-400/20 bg-emerald-400/8 px-5 py-4 text-sm text-emerald-100">
          {okMsg}
        </div>
      ) : null}

      <div className="grid gap-6 xl:grid-cols-[0.92fr_1.08fr]">
        <SectionCard title="Cycle Setup" subtitle="Foundational org and period settings">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="grid gap-2 text-sm text-white/65">
              <span>Company name</span>
              <input
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="h-11 rounded-2xl border border-white/10 bg-black/20 px-4 text-white outline-none"
              />
            </label>

            <label className="grid gap-2 text-sm text-white/65">
              <span>Org slug</span>
              <input
                value={orgSlug}
                readOnly
                className="h-11 rounded-2xl border border-white/10 bg-black/20 px-4 text-white/65 outline-none"
              />
            </label>

            <label className="grid gap-2 text-sm text-white/65">
              <span>Year</span>
              <input
                value={String(year)}
                onChange={(e) => setYear(toNumber(e.target.value, year))}
                className="h-11 rounded-2xl border border-white/10 bg-black/20 px-4 text-white outline-none"
                inputMode="numeric"
              />
            </label>

            <label className="grid gap-2 text-sm text-white/65">
              <span>Quarter</span>
              <select
                value={String(quarter)}
                onChange={(e) => setQuarter(toNumber(e.target.value, quarter))}
                className="h-11 rounded-2xl border border-white/10 bg-black/20 px-4 text-white outline-none"
              >
                <option value="1">Q1</option>
                <option value="2">Q2</option>
                <option value="3">Q3</option>
                <option value="4">Q4</option>
              </select>
            </label>
          </div>
        </SectionCard>

        <SectionCard
          title="Departments"
          subtitle="Create the initial org structure"
          actions={
            <button
              type="button"
              onClick={addDepartment}
              className="rounded-2xl border border-white/12 bg-white/5 px-4 py-2 text-sm font-semibold text-white/80 transition hover:bg-white/8 hover:text-white"
            >
              + Add department
            </button>
          }
        >
          <div className="space-y-3">
            {departments.map((d, idx) => (
              <div key={`dept-${idx}`} className="grid gap-3 md:grid-cols-[1fr_auto]">
                <input
                  value={d.name}
                  onChange={(e) => {
                    const v = e.target.value;
                    setDepartments((prev) => prev.map((x, i) => (i === idx ? { ...x, name: v } : x)));
                  }}
                  className="h-11 rounded-2xl border border-white/10 bg-black/20 px-4 text-white outline-none"
                  placeholder="Department name"
                />
                <button
                  type="button"
                  onClick={() => removeDepartment(idx)}
                  disabled={departments.length <= 1}
                  className="rounded-2xl border border-red-400/20 bg-red-400/8 px-4 py-2 text-sm font-semibold text-red-100 transition hover:bg-red-400/12 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Remove
                </button>
              </div>
            ))}
          </div>

          <div className="mt-4 text-sm text-white/45">
            KPI department names must match one of the departments above.
          </div>
        </SectionCard>
      </div>

      <div className="mt-6">
        <SectionCard
          title="Initial KPIs"
          subtitle="Seed the first KPI set for this cycle"
          actions={
            <button
              type="button"
              onClick={addKpi}
              className="rounded-2xl border border-white/12 bg-white/5 px-4 py-2 text-sm font-semibold text-white/80 transition hover:bg-white/8 hover:text-white"
            >
              + Add KPI
            </button>
          }
        >
          <div className="overflow-hidden rounded-[20px] border border-white/10">
            <div className="overflow-x-auto">
              <table className="min-w-230 text-left">
                <thead className="bg-white/5">
                  <tr>
                    <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">
                      Title
                    </th>
                    <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">
                      Department
                    </th>
                    <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">
                      Unit
                    </th>
                    <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">
                      Target
                    </th>
                    <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">
                      Current
                    </th>
                    <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {kpis.map((k, idx) => (
                    <tr key={`kpi-${idx}`} className="border-t border-white/8">
                      <td className="px-4 py-3">
                        <input
                          value={k.title}
                          onChange={(e) => {
                            const v = e.target.value;
                            setKpis((prev) => prev.map((x, i) => (i === idx ? { ...x, title: v } : x)));
                          }}
                          className="h-10 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-sm text-white outline-none"
                          placeholder="Bookings per week"
                        />
                      </td>

                      <td className="px-4 py-3">
                        <input
                          value={k.departmentName}
                          onChange={(e) => {
                            const v = e.target.value;
                            setKpis((prev) => prev.map((x, i) => (i === idx ? { ...x, departmentName: v } : x)));
                          }}
                          className="h-10 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-sm text-white outline-none"
                          placeholder="Sales"
                        />
                      </td>

                      <td className="px-4 py-3">
                        <input
                          value={k.unit}
                          onChange={(e) => {
                            const v = e.target.value;
                            setKpis((prev) => prev.map((x, i) => (i === idx ? { ...x, unit: v } : x)));
                          }}
                          className="h-10 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-sm text-white outline-none"
                          placeholder="count"
                        />
                      </td>

                      <td className="px-4 py-3">
                        <input
                          value={k.target}
                          onChange={(e) => {
                            const v = e.target.value;
                            setKpis((prev) => prev.map((x, i) => (i === idx ? { ...x, target: v } : x)));
                          }}
                          className="h-10 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-sm text-white outline-none"
                          inputMode="decimal"
                        />
                      </td>

                      <td className="px-4 py-3">
                        <input
                          value={k.current}
                          onChange={(e) => {
                            const v = e.target.value;
                            setKpis((prev) => prev.map((x, i) => (i === idx ? { ...x, current: v } : x)));
                          }}
                          className="h-10 w-full rounded-xl border border-white/10 bg-black/20 px-3 text-sm text-white outline-none"
                          inputMode="decimal"
                        />
                      </td>

                      <td className="px-4 py-3">
                        <button
                          type="button"
                          onClick={() => removeKpi(idx)}
                          disabled={kpis.length <= 1}
                          className="rounded-2xl border border-red-400/20 bg-red-400/8 px-3 py-2 text-xs font-semibold text-red-100 transition hover:bg-red-400/12 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => void submit()}
              disabled={!canSubmit || saving || loading}
              className="rounded-2xl border border-white/14 bg-white/10 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-white/15 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {saving ? "Saving..." : "Save onboarding"}
            </button>

            <button
              type="button"
              onClick={() => router.push(`/o/${encodeURIComponent(orgSlug)}/dashboard`)}
              className="rounded-2xl border border-white/12 bg-white/5 px-5 py-2.5 text-sm font-semibold text-white/75 transition hover:bg-white/8 hover:text-white"
            >
              Skip
            </button>
          </div>
        </SectionCard>
      </div>
    </AppShell>
  );
}