"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabaseClient";
import { AppPageHeader, AppShell } from "@/components/app/AppShell";
import EmptyState from "@/components/ui/EmptyState";
import ProgressBar from "@/components/ui/ProgressBar";
import SectionCard from "@/components/ui/SectionCard";
import StatCard from "@/components/ui/StatCard";
import StatusBadge from "@/components/ui/StatusBadge";

type Cycle = { id: string; year: number; quarter: number; status: string };
type Company = {
  score: number;
  label: string;
  summary: string;
  total_objectives: number;
  active_okrs: number;
  active_kpis: number;
  open_tasks: number;
  completed_tasks: number;
  overdue_tasks: number;
  task_completion_rate: number;
};
type DepartmentRow = {
  id: string;
  name: string;
  score: number;
  label: string;
  objectives: number;
  okrs: number;
  kpis: number;
  open_tasks: number;
  completed_tasks: number;
};
type ObjectiveRow = {
  id: string;
  title: string;
  status: string;
  progress: number;
  department_id?: string | null;
  department_name?: string | null;
  okr_count: number;
};
type KpiRow = {
  id: string;
  title: string;
  description?: string | null;
  department_id?: string | null;
  department_name?: string | null;
  current_value: number;
  target_value: number;
  weight: number;
  score: number;
  label: string;
  updated_at: string;
};
type TaskRow = {
  id: string;
  title: string;
  status: string;
  priority: string;
  department_id?: string | null;
  department_name?: string | null;
  assigned_to_user_id?: string | null;
  due_date?: string | null;
};
type DashboardResponse = {
  ok: boolean;
  org?: { id: string; slug: string; name: string };
  cycle?: Cycle | null;
  company?: Company;
  departments?: DepartmentRow[];
  objectives?: ObjectiveRow[];
  kpis?: KpiRow[];
  tasks?: TaskRow[];
  ai_report?: { title: string; summary: string | null; created_at: string } | null;
  role?: string;
  visibility?: string;
  error?: string;
};

function getErrorMessage(err: unknown, fallback: string) {
  if (err instanceof Error) return err.message;
  if (typeof err === "string") return err;
  return fallback;
}

async function safeParseJson(text: string): Promise<unknown> {
  if (!text.trim()) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function clamp(value: number) {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(100, value));
}

function numberFmt(value: unknown) {
  const num = Number(value);
  return Number.isFinite(num) ? num.toLocaleString() : "—";
}

function toneFromStatus(status?: string | null) {
  const value = String(status ?? "").toLowerCase();
  if (["on track", "on_track", "completed", "done", "active"].includes(value)) return "success" as const;
  if (["at risk", "at_risk", "blocked"].includes(value)) return "warning" as const;
  if (["off track", "off_track", "cancelled"].includes(value)) return "danger" as const;
  if (["in_progress", "in progress", "todo", "pending_approval"].includes(value)) return "info" as const;
  return "neutral" as const;
}

function fmtDate(iso?: string | null) {
  if (!iso) return "—";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString();
}

function cycleLabel(cycle?: Cycle | null) {
  if (!cycle) return "No active cycle";
  return `Q${cycle.quarter} ${cycle.year} · ${cycle.status}`;
}

export default function DashboardPage() {
  const params = useParams<{ slug: string }>();
  const router = useRouter();
  const orgSlug = String(params?.slug ?? "").trim();

  const [sessionEmail, setSessionEmail] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const [cycle, setCycle] = useState<Cycle | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [departments, setDepartments] = useState<DepartmentRow[]>([]);
  const [objectives, setObjectives] = useState<ObjectiveRow[]>([]);
  const [kpis, setKpis] = useState<KpiRow[]>([]);
  const [tasks, setTasks] = useState<TaskRow[]>([]);
  const [aiReport, setAiReport] = useState<DashboardResponse["ai_report"]>(null);
  const [role, setRole] = useState<string | null>(null);
  const [visibility, setVisibility] = useState<string | null>(null);

  const ensureAuth = useCallback(async (): Promise<Session | null> => {
    const { data } = await supabase.auth.getSession();
    const session = data.session;
    setSessionEmail(session?.user?.email ?? null);

    if (!session) {
      router.replace("/auth");
      return null;
    }

    return session;
  }, [router]);

  const loadDashboard = useCallback(async () => {
    setMsg(null);
    setLoading(true);

    try {
      const session = await ensureAuth();
      if (!session) return;

      const apiUrl = new URL(`/api/o/${encodeURIComponent(orgSlug)}/dashboard`, window.location.origin).toString();
      const res = await fetch(apiUrl, {
        method: "GET",
        headers: { Authorization: `Bearer ${session.access_token}` },
        cache: "no-store",
      });

      const raw = await res.text();
      const parsed = (await safeParseJson(raw)) as DashboardResponse | null;
      if (!res.ok || !parsed || parsed.ok !== true) {
        throw new Error(parsed?.error || raw || `Failed (HTTP ${res.status})`);
      }

      setCycle(parsed.cycle ?? null);
      setCompany(parsed.company ?? null);
      setDepartments(Array.isArray(parsed.departments) ? parsed.departments : []);
      setObjectives(Array.isArray(parsed.objectives) ? parsed.objectives : []);
      setKpis(Array.isArray(parsed.kpis) ? parsed.kpis : []);
      setTasks(Array.isArray(parsed.tasks) ? parsed.tasks : []);
      setAiReport(parsed.ai_report ?? null);
      setRole(parsed.role ?? null);
      setVisibility(parsed.visibility ?? null);
    } catch (error: unknown) {
      setMsg(getErrorMessage(error, "Failed to load dashboard"));
    } finally {
      setLoading(false);
    }
  }, [ensureAuth, orgSlug]);

  useEffect(() => {
    if (!orgSlug) return;
    void loadDashboard();
  }, [orgSlug, loadDashboard]);

  const topRiskKpis = useMemo(() => [...kpis].sort((a, b) => a.score - b.score).slice(0, 5), [kpis]);
  const topObjectives = useMemo(() => [...objectives].sort((a, b) => b.progress - a.progress).slice(0, 6), [objectives]);
  const executionPulse = useMemo(
    () => [...tasks].filter((task) => task.status !== "done" && task.status !== "cancelled").slice(0, 6),
    [tasks]
  );

  const stats = useMemo(() => {
    const completedObjectives = objectives.filter((objective) => objective.progress >= 100 || objective.status === "completed").length;
    return {
      companyScore: clamp(Number(company?.score ?? 0)),
      activeObjectives: company?.total_objectives ?? objectives.length,
      activeOkrs: company?.active_okrs ?? 0,
      activeKpis: company?.active_kpis ?? kpis.length,
      openTasks: company?.open_tasks ?? tasks.filter((task) => !["done", "cancelled"].includes(task.status)).length,
      completedTasks: company?.completed_tasks ?? tasks.filter((task) => task.status === "done").length,
      overdueTasks: company?.overdue_tasks ?? 0,
      completedObjectives,
      taskCompletionRate: company?.task_completion_rate ?? 0,
    };
  }, [company, kpis, objectives, tasks]);

  const refreshDashboard = useCallback(async () => {
    setRefreshing(true);
    await loadDashboard();
    setRefreshing(false);
  }, [loadDashboard]);

  return (
    <AppShell
      slug={orgSlug}
      sessionEmail={sessionEmail}
      topActions={
        <button
          type="button"
          onClick={() => void refreshDashboard()}
          disabled={refreshing}
          className="rounded-2xl border border-white/12 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white/80 transition hover:bg-white/8 hover:text-white disabled:cursor-not-allowed disabled:opacity-60"
        >
          {refreshing ? "Refreshing..." : "Refresh dashboard"}
        </button>
      }
    >
      <AppPageHeader
        eyebrow={cycleLabel(cycle)}
        title="Dashboard"
        description="Executive performance overview that connects objectives, OKRs, KPIs, task execution, and the latest Mach3 analysis in one screen."
      />

      {loading ? (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, index) => (
            <div key={index} className="h-36 animate-pulse rounded-3xl border border-white/10 bg-white/5" />
          ))}
        </div>
      ) : (
        <>
          {msg ? (
            <div className="mb-6 rounded-[20px] border border-red-400/20 bg-red-400/8 px-5 py-4 text-sm text-red-100">
              {msg}
            </div>
          ) : null}

          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <StatCard
              title="Company Score"
              value={numberFmt(stats.companyScore)}
              hint={company?.label ?? "No score available"}
              trend="Blended from KPI, OKR, objective, and execution progress"
              tone={stats.companyScore >= 85 ? "success" : stats.companyScore >= 60 ? "warning" : "danger"}
            />
            <StatCard
              title="Objectives"
              value={numberFmt(stats.activeObjectives)}
              hint={`${numberFmt(stats.completedObjectives)} completed or fully progressed`}
              tone="info"
            />
            <StatCard
              title="Open Tasks"
              value={numberFmt(stats.openTasks)}
              hint={`${numberFmt(stats.completedTasks)} completed · ${numberFmt(stats.overdueTasks)} overdue`}
              tone={stats.overdueTasks > 0 ? "warning" : "success"}
            />
            <StatCard
              title="Active OKRs / KPIs"
              value={`${numberFmt(stats.activeOkrs)} / ${numberFmt(stats.activeKpis)}`}
              hint={`Task completion ${numberFmt(stats.taskCompletionRate)}%`}
              tone="default"
            />
          </div>

          <div className="mt-6 grid gap-6 xl:grid-cols-[1.35fr_0.95fr]">
            <SectionCard title="Company Health" subtitle={visibility ? `View scope: ${visibility} · Role: ${role ?? "member"}` : undefined}>
              <div className="grid gap-5 md:grid-cols-2">
                <div className="rounded-[20px] border border-white/10 bg-white/3 p-5">
                  <div className="text-sm font-semibold text-white/70">Health Score</div>
                  <div className="mt-4">
                    <ProgressBar value={stats.companyScore} />
                  </div>
                  <div className="mt-4 flex items-center gap-2">
                    <StatusBadge tone={toneFromStatus(company?.label)}>{company?.label ?? "No label"}</StatusBadge>
                  </div>
                  <p className="mt-4 text-sm leading-6 text-white/55">
                    {company?.summary ?? "Performance summary will appear here once data is available."}
                  </p>
                </div>

                <div className="rounded-[20px] border border-white/10 bg-white/3 p-5">
                  <div className="text-sm font-semibold text-white/70">Execution Snapshot</div>
                  <div className="mt-4 space-y-3 text-sm text-white/65">
                    <div className="flex items-center justify-between rounded-2xl border border-white/8 bg-white/3 px-4 py-3">
                      <span>Cycle</span>
                      <span className="font-semibold text-white">{cycleLabel(cycle)}</span>
                    </div>
                    <div className="flex items-center justify-between rounded-2xl border border-white/8 bg-white/3 px-4 py-3">
                      <span>Departments</span>
                      <span className="font-semibold text-white">{numberFmt(departments.length)}</span>
                    </div>
                    <div className="flex items-center justify-between rounded-2xl border border-white/8 bg-white/3 px-4 py-3">
                      <span>Task completion</span>
                      <span className="font-semibold text-white">{numberFmt(stats.taskCompletionRate)}%</span>
                    </div>
                    <div className="flex items-center justify-between rounded-2xl border border-white/8 bg-white/3 px-4 py-3">
                      <span>At-risk KPIs</span>
                      <span className="font-semibold text-white">{numberFmt(kpis.filter((kpi) => kpi.score < 60).length)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </SectionCard>

            <SectionCard title="Mach3 Analysis" subtitle="Latest executive intelligence output">
              {aiReport ? (
                <div className="rounded-[20px] border border-white/10 bg-white/3 p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-lg font-bold text-white">{aiReport.title}</div>
                      <div className="mt-1 text-xs uppercase tracking-[0.14em] text-white/35">{fmtDate(aiReport.created_at)}</div>
                    </div>
                    <StatusBadge tone="info">Mach3</StatusBadge>
                  </div>
                  <p className="mt-4 text-sm leading-7 text-white/60">
                    {aiReport.summary ?? "No AI summary was stored for the latest report."}
                  </p>
                </div>
              ) : (
                <EmptyState
                  title="No Mach3 report found"
                  description="Once the AI analysis layer writes to ai_reports, the latest executive summary will appear here."
                />
              )}
            </SectionCard>
          </div>

          <div className="mt-6 grid gap-6 xl:grid-cols-[1.05fr_1.2fr]">
            <SectionCard title="Department Performance" subtitle="Ranked by current blended score">
              {departments.length ? (
                <div className="grid gap-4">
                  {departments.map((department) => (
                    <div key={department.id} className="rounded-[20px] border border-white/10 bg-white/3 p-4">
                      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                        <div>
                          <div className="text-base font-bold text-white">{department.name}</div>
                          <div className="mt-2 flex flex-wrap items-center gap-2">
                            <StatusBadge tone={toneFromStatus(department.label)}>{department.label}</StatusBadge>
                            <span className="text-xs text-white/40">{department.objectives} objectives</span>
                            <span className="text-xs text-white/40">{department.okrs} OKRs</span>
                            <span className="text-xs text-white/40">{department.kpis} KPIs</span>
                          </div>
                          <div className="mt-3 text-sm text-white/50">
                            {department.open_tasks} open tasks · {department.completed_tasks} completed tasks
                          </div>
                        </div>

                        <div className="min-w-45">
                          <div className="mb-2 text-right text-2xl font-black text-white">{numberFmt(department.score)}</div>
                          <ProgressBar value={department.score} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState title="No departments found" description="Create departments and connect work to them so the department leaderboard can render." />
              )}
            </SectionCard>

            <SectionCard title="Priority KPIs" subtitle="Lowest-scoring KPIs surfaced first">
              {topRiskKpis.length ? (
                <div className="overflow-hidden rounded-[20px] border border-white/10">
                  <div className="overflow-x-auto">
                    <table className="min-w-full text-left">
                      <thead className="bg-white/5">
                        <tr>
                          <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">KPI</th>
                          <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">Department</th>
                          <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">Current / Target</th>
                          <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">Score</th>
                          <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">Status</th>
                          <th className="px-4 py-3 text-xs font-semibold uppercase tracking-[0.12em] text-white/40">Updated</th>
                        </tr>
                      </thead>
                      <tbody>
                        {topRiskKpis.map((kpi) => (
                          <tr key={kpi.id} className="border-t border-white/8 transition hover:bg-white/5">
                            <td className="px-4 py-4">
                              <div className="font-semibold text-white">{kpi.title}</div>
                              {kpi.description ? <div className="mt-1 text-xs text-white/45">{kpi.description}</div> : null}
                            </td>
                            <td className="px-4 py-4 text-sm text-white/60">{kpi.department_name ?? "Company-wide"}</td>
                            <td className="px-4 py-4 text-sm text-white/75">{numberFmt(kpi.current_value)} / {numberFmt(kpi.target_value)}</td>
                            <td className="px-4 py-4"><div className="min-w-35"><ProgressBar value={kpi.score} /></div></td>
                            <td className="px-4 py-4"><StatusBadge tone={toneFromStatus(kpi.label)}>{kpi.label}</StatusBadge></td>
                            <td className="px-4 py-4 text-sm text-white/50">{fmtDate(kpi.updated_at)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <EmptyState title="No KPIs found" description="Create KPIs for the active cycle to populate the performance table." />
              )}
            </SectionCard>
          </div>

          <div className="mt-6 grid gap-6 xl:grid-cols-[1.1fr_1fr]">
            <SectionCard title="Objectives Overview" subtitle="Top strategic objectives by progress">
              {topObjectives.length ? (
                <div className="grid gap-3">
                  {topObjectives.map((objective) => (
                    <div key={objective.id} className="rounded-[18px] border border-white/10 bg-white/3 p-4">
                      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                        <div>
                          <div className="font-semibold text-white">{objective.title}</div>
                          <div className="mt-2 flex flex-wrap items-center gap-2">
                            <StatusBadge tone={toneFromStatus(objective.status)}>{objective.status}</StatusBadge>
                            <span className="text-xs text-white/40">{objective.department_name ?? "Company-wide"}</span>
                            <span className="text-xs text-white/40">{objective.okr_count} OKRs</span>
                          </div>
                        </div>
                        <div className="min-w-45">
                          <div className="mb-2 text-right text-xl font-black text-white">{numberFmt(objective.progress)}%</div>
                          <ProgressBar value={objective.progress} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState title="No objectives found" description="Create company or department objectives first to make the strategy layer visible here." />
              )}
            </SectionCard>

            <SectionCard title="Execution Pulse" subtitle="Open work that still needs attention">
              {executionPulse.length ? (
                <div className="grid gap-3">
                  {executionPulse.map((task) => (
                    <div key={task.id} className="rounded-[18px] border border-white/10 bg-white/3 p-4">
                      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                        <div>
                          <div className="font-semibold text-white">{task.title}</div>
                          <div className="mt-2 flex flex-wrap items-center gap-2">
                            <StatusBadge tone={toneFromStatus(task.status)}>{task.status}</StatusBadge>
                            <StatusBadge tone={task.priority === "critical" || task.priority === "high" ? "warning" : "neutral"}>{task.priority}</StatusBadge>
                            <span className="text-xs text-white/40">{task.department_name ?? "Company-wide"}</span>
                          </div>
                        </div>
                        <div className="text-sm text-white/52">Due {fmtDate(task.due_date)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState title="No active tasks found" description="As soon as teams create or generate tasks from JTBD clusters, this panel will show execution pressure points." />
              )}
            </SectionCard>
          </div>
        </>
      )}
    </AppShell>
  );
}
