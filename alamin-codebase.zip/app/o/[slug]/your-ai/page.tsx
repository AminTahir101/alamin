"use client";

import { useCallback, useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabaseClient";
import { AppPageHeader, AppShell } from "@/components/app/AppShell";
import OrgAiCopilot from "@/components/ai/OrgAiCopilot";

function getErrorMessage(err: unknown, fallback: string) {
  if (err instanceof Error) return err.message;
  if (typeof err === "string") return err;
  return fallback;
}

export default function YourAiPage() {
  const params = useParams<{ slug: string }>();
  const router = useRouter();
  const orgSlug = String(params?.slug ?? "").trim();

  const [loading, setLoading] = useState(true);
  const [sessionEmail, setSessionEmail] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const ensureAuth = useCallback(async (): Promise<Session | null> => {
    const { data } = await supabase.auth.getSession();
    const session = data.session;

    setSessionEmail(session?.user?.email ?? null);

    if (!session) {
      router.replace("/auth");
      return null;
    }

    return session;
  }, [router]);

  useEffect(() => {
    let active = true;

    void (async () => {
      try {
        setMsg(null);
        const session = await ensureAuth();
        if (!active) return;
        if (!session) return;
      } catch (err: unknown) {
        if (!active) return;
        setMsg(getErrorMessage(err, "Failed to load Your AI"));
      } finally {
        if (!active) return;
        setLoading(false);
      }
    })();

    return () => {
      active = false;
    };
  }, [ensureAuth]);

  return (
    <AppShell slug={orgSlug} sessionEmail={sessionEmail}>
      <AppPageHeader
        eyebrow="AI performance intelligence"
        title="Your AI"
        description="A live AI assistant grounded in your company data, active cycle, strategy chain, and execution records."
      />

      {msg ? (
        <div className="mb-6 rounded-2xl border border-red-400/20 bg-red-400/10 px-4 py-3 text-sm text-red-100">
          {msg}
        </div>
      ) : null}

      {loading ? (
        <section className="rounded-4xl border border-white/10 bg-white/5 p-8 text-sm text-white/55">
          Loading Your AI...
        </section>
      ) : (
        <OrgAiCopilot slug={orgSlug} />
      )}
    </AppShell>
  );
}