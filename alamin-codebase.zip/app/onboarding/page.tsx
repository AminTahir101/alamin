"use client";

import type React from "react";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/app/lib/supabaseClient";
import Link from "next/link";

type Organization = {
  id: string;
  name: string;
  slug: string;
  created_at: string;
};

type SupabaseErrorShape = {
  message?: unknown;
  error_description?: unknown;
  hint?: unknown;
  details?: unknown;
};

function slugify(input: string) {
  return input
    .trim()
    .toLowerCase()
    .replace(/['"]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 48);
}

function getErrorMessage(err: unknown, fallback: string) {
  if (err instanceof Error) return err.message;
  if (typeof err === "string") return err;

  if (err && typeof err === "object") {
    const maybe = err as SupabaseErrorShape;
    if (typeof maybe.message === "string" && maybe.message.trim()) return maybe.message;
    if (typeof maybe.error_description === "string" && maybe.error_description.trim())
      return maybe.error_description;
    if (typeof maybe.details === "string" && maybe.details.trim()) return maybe.details;
    if (typeof maybe.hint === "string" && maybe.hint.trim()) return maybe.hint;
  }

  return fallback;
}

function isOrganization(value: unknown): value is Organization {
  if (!value || typeof value !== "object") return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.id === "string" &&
    typeof v.name === "string" &&
    typeof v.slug === "string" &&
    typeof v.created_at === "string"
  );
}

type OrgMemberRowUnknown = { organizations?: unknown };

export default function OnboardingPage() {
  const router = useRouter();

  const [checking, setChecking] = useState(true);
  const [sessionEmail, setSessionEmail] = useState<string | null>(null);

  const [orgs, setOrgs] = useState<Organization[]>([]);
  const [loadingOrgs, setLoadingOrgs] = useState(false);

  const [companyName, setCompanyName] = useState("");
  const [slugInput, setSlugInput] = useState("");

  const computedSlug = useMemo(() => {
    const base = slugInput.trim() ? slugInput : companyName;
    return slugify(base);
  }, [slugInput, companyName]);

  const [creating, setCreating] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const [showCreate, setShowCreate] = useState(false);

  async function loadOrgs() {
    setMsg(null);
    setLoadingOrgs(true);

    const { data: sessData, error: sessErr } = await supabase.auth.getSession();
    if (sessErr) {
      setLoadingOrgs(false);
      throw sessErr;
    }

    const session = sessData.session;
    setSessionEmail(session?.user?.email ?? null);

    if (!session) {
      setLoadingOrgs(false);
      return;
    }

    const { data, error } = await supabase
      .from("organization_members")
      .select("organizations(id,name,slug,created_at)")
      .order("created_at", { ascending: false });

    if (error) {
      setLoadingOrgs(false);
      throw error;
    }

    const rows = (Array.isArray(data) ? data : []) as unknown[];

    const mapped: Organization[] = rows
      .map((r) => (r as OrgMemberRowUnknown).organizations)
      .filter(isOrganization);

    const unique = Array.from(new Map(mapped.map((o) => [o.id, o])).values());
    setOrgs(unique);

    setLoadingOrgs(false);
  }

  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        const { data } = await supabase.auth.getSession();
        if (!mounted) return;

        if (!data.session) {
          const wait = await new Promise<boolean>((resolve) => {
            let subscription: { unsubscribe: () => void } | null = null;

            const timeout = setTimeout(() => {
              if (subscription) subscription.unsubscribe();
              resolve(false);
            }, 1500);

            const { data: subData } = supabase.auth.onAuthStateChange((event) => {
              if (event === "SIGNED_IN") {
                clearTimeout(timeout);
                if (subscription) subscription.unsubscribe();
                resolve(true);
              }
            });

            subscription = subData.subscription;
          });

          if (!wait) {
            router.replace("/auth");
            return;
          }
        }

        await loadOrgs();
      } catch (e: unknown) {
        setMsg(getErrorMessage(e, "Failed to load onboarding"));
      } finally {
        setChecking(false);
      }
    })();

    return () => {
      mounted = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleCreateOrg(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMsg(null);

    const name = companyName.trim();
    const slug = computedSlug;

    if (!name) return setMsg("Company name is required.");

    setCreating(true);
    try {
      const { error } = await supabase.rpc("create_organization", {
        org_name: name,
        org_slug: slug,
      });

      if (error) throw error;

      router.push(`/o/${slug}/dashboard`);
    } catch (e: unknown) {
      const message = getErrorMessage(e, "Failed to create organization.");
      if (message.toLowerCase().includes("duplicate")) {
        setMsg("This slug is already taken. Choose another one.");
      } else {
        setMsg(message);
      }
    } finally {
      setCreating(false);
    }
  }

  async function logout() {
    await supabase.auth.signOut();
    router.replace("/auth");
  }

  if (checking) {
    return (
      <div style={s.shell}>
        <div style={s.center}>
          <div style={s.card}>
            <div style={s.skeletonTitle} />
            <div style={s.skeletonLine} />
            <div style={s.skeletonLine} />
          </div>
        </div>
      </div>
    );
  }

  const hasOrgs = orgs.length > 0;

  return (
    <div style={s.shell}>
      <header style={s.header}>
        <div style={s.headerInner}>
<Link href="/" style={s.brand}>
  <span style={s.logoMark} />
  <span style={s.brandText}>ALAMIN</span>
</Link>

          <div style={s.headerRight}>
            {sessionEmail && <div style={s.headerMeta}>{sessionEmail}</div>}
            <button type="button" onClick={logout} style={s.ghostBtn}>
              Logout
            </button>
          </div>
        </div>
      </header>

      <main style={s.main}>
        <div style={s.hero}>
          <div>
            <h1 style={s.h1}>{hasOrgs ? "Select an organization" : "Create your organization"}</h1>
            <p style={s.p}>
              {hasOrgs
                ? "Choose where you want to work. You can create a new org anytime."
                : "This becomes your tenant (like a workspace)."}
            </p>
          </div>

          <div style={s.heroActions}>
            <button
              type="button"
              onClick={() => setShowCreate((v) => !v)}
              style={s.primaryBtn}
            >
              {hasOrgs ? "Create organization" : "Create now"}
            </button>
            <button
              type="button"
              onClick={() => loadOrgs().catch((e: unknown) => setMsg(getErrorMessage(e, "Refresh failed")))}
              style={s.secondaryBtn}
              disabled={loadingOrgs}
            >
              {loadingOrgs ? "Refreshing..." : "Refresh"}
            </button>
          </div>
        </div>

        {msg && (
          <div style={s.alert}>
            <div style={s.alertTitle}>Action needed</div>
            <div style={s.alertBody}>{msg}</div>

            {msg.toLowerCase().includes("infinite recursion detected in policy") && (
              <div style={s.alertHint}>
                This is a Supabase <b>RLS policy</b> issue on <b>organization_members</b>. Fix the
                policy (not UI) to proceed.
              </div>
            )}
          </div>
        )}

        <div style={s.grid}>
          <section style={s.panel}>
            <div style={s.panelHeader}>
              <div style={s.panelTitle}>Organizations</div>
              <div style={s.panelMeta}>{hasOrgs ? `${orgs.length} found` : "None yet"}</div>
            </div>

            {loadingOrgs ? (
              <div style={s.list}>
                <div style={s.orgSkeleton} />
                <div style={s.orgSkeleton} />
                <div style={s.orgSkeleton} />
              </div>
            ) : hasOrgs ? (
              <div style={s.list}>
                {orgs.map((o) => (
                  <button
                    key={o.id}
                    type="button"
                    onClick={() => router.push(`/o/${o.slug}/dashboard`)}
                    style={s.orgRowBtn}
                  >
                    <div style={s.orgLeft}>
                      <div style={s.orgName}>{o.name}</div>
                      <div style={s.orgPath}>/o/{o.slug}</div>
                    </div>
                    <div style={s.orgRight}>
                      <span style={s.pill}>Open</span>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div style={s.empty}>
                <div style={s.emptyTitle}>No organizations yet</div>
                <div style={s.emptyText}>Create one to access your dashboard.</div>
              </div>
            )}
          </section>

          <section style={s.panel}>
            <div style={s.panelHeader}>
              <div style={s.panelTitle}>Create organization</div>
              <div style={s.panelMeta}>New workspace</div>
            </div>

            <div style={{ padding: 18 }}>
              {!showCreate && hasOrgs ? (
                <div style={s.callout}>
                  <div style={s.calloutTitle}>Create a new org</div>
                  <div style={s.calloutText}>
                    Use this when you need a separate workspace for another company or team.
                  </div>
                  <button type="button" onClick={() => setShowCreate(true)} style={s.primaryBtnFull}>
                    Create organization
                  </button>
                </div>
              ) : (
                <form onSubmit={handleCreateOrg} style={s.form}>
                  <label style={s.label}>
                    Company name
                    <input
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      placeholder="e.g., ALAMIN Inc."
                      style={s.input}
                      required
                    />
                  </label>

                  <label style={s.label}>
                    Slug (optional)
                    <input
                      value={slugInput}
                      onChange={(e) => setSlugInput(e.target.value)}
                      placeholder="e.g., alamin"
                      style={s.input}
                    />
                  </label>

                  <div style={s.slugLine}>
                    Final URL: <span style={s.mono}>/o/{computedSlug || "—"}</span>
                  </div>

                  <button type="submit" disabled={creating} style={s.primaryBtnFull}>
                    {creating ? "Creating..." : "Create organization"}
                  </button>

                  {hasOrgs && (
                    <button
                      type="button"
                      onClick={() => setShowCreate(false)}
                      style={s.linkBtn}
                      disabled={creating}
                    >
                      Cancel
                    </button>
                  )}
                </form>
              )}
            </div>
          </section>
        </div>

        <footer style={s.footer}>
          <div style={s.footerText}>
            By continuing, you’re creating a tenant workspace for ALAMIN.
          </div>
        </footer>
      </main>
    </div>
  );
}

const s: Record<string, React.CSSProperties> = {
  shell: {
    minHeight: "100vh",
    background:
      "radial-gradient(1000px 600px at 20% 10%, rgba(255,255,255,0.10), transparent 60%), radial-gradient(1000px 600px at 80% 20%, rgba(255,255,255,0.08), transparent 55%), #000",
    color: "white",
  },

  header: {
    position: "sticky",
    top: 0,
    zIndex: 20,
    backdropFilter: "blur(14px)",
    background: "rgba(0,0,0,0.65)",
    borderBottom: "1px solid rgba(255,255,255,0.10)",
  },
  headerInner: {
    maxWidth: 1120,
    margin: "0 auto",
    padding: "14px 18px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
  },
  brand: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    textDecoration: "none",
    color: "white",
  },
  logoMark: {
    width: 16,
    height: 16,
    borderRadius: 6,
    background: "linear-gradient(135deg, rgba(255,255,255,0.95), rgba(255,255,255,0.25))",
    boxShadow: "0 0 0 1px rgba(255,255,255,0.15) inset, 0 10px 30px rgba(255,255,255,0.08)",
  },
  brandText: { fontWeight: 900, letterSpacing: 0.4 },
  headerRight: { display: "flex", alignItems: "center", gap: 12 },
  headerMeta: { fontSize: 12, color: "rgba(255,255,255,0.70)" },

  ghostBtn: {
    height: 36,
    padding: "0 12px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.16)",
    background: "rgba(255,255,255,0.04)",
    color: "white",
    cursor: "pointer",
    fontWeight: 700,
    fontSize: 12,
  },

  main: {
    maxWidth: 1120,
    margin: "0 auto",
    padding: "26px 18px 44px",
  },

  hero: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-end",
    gap: 14,
    flexWrap: "wrap",
    padding: "18px 2px 8px",
  },
  h1: { fontSize: 28, fontWeight: 950, letterSpacing: -0.3, margin: 0 },
  p: { margin: "8px 0 0", color: "rgba(255,255,255,0.72)", maxWidth: 620, lineHeight: 1.6 },

  heroActions: { display: "flex", gap: 10, alignItems: "center" },

  primaryBtn: {
    height: 40,
    padding: "0 14px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.16)",
    background: "rgba(255,255,255,0.92)",
    color: "#000",
    cursor: "pointer",
    fontWeight: 900,
    fontSize: 12,
  },
  secondaryBtn: {
    height: 40,
    padding: "0 14px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.16)",
    background: "rgba(0,0,0,0.22)",
    color: "rgba(255,255,255,0.9)",
    cursor: "pointer",
    fontWeight: 900,
    fontSize: 12,
  },

  alert: {
    marginTop: 14,
    borderRadius: 16,
    border: "1px solid rgba(255,160,160,0.28)",
    background: "rgba(255,90,90,0.10)",
    padding: 14,
  },
  alertTitle: { fontWeight: 900, marginBottom: 6 },
  alertBody: { color: "rgba(255,220,220,0.95)", whiteSpace: "pre-wrap", lineHeight: 1.6 },
  alertHint: {
    marginTop: 10,
    paddingTop: 10,
    borderTop: "1px solid rgba(255,160,160,0.20)",
    color: "rgba(255,220,220,0.85)",
    lineHeight: 1.6,
    fontSize: 13,
  },

  grid: {
    marginTop: 18,
    display: "grid",
    gridTemplateColumns: "1.15fr 0.85fr",
    gap: 14,
  },

  panel: {
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,0.14)",
    background: "rgba(255,255,255,0.06)",
    boxShadow: "0 30px 70px rgba(0,0,0,0.55)",
    overflow: "hidden",
  },
  panelHeader: {
    padding: 18,
    borderBottom: "1px solid rgba(255,255,255,0.10)",
    display: "flex",
    alignItems: "baseline",
    justifyContent: "space-between",
    gap: 12,
  },
  panelTitle: { fontWeight: 950 },
  panelMeta: { fontSize: 12, color: "rgba(255,255,255,0.62)" },

  list: { padding: 10, display: "grid", gap: 8 },
  orgRowBtn: {
    width: "100%",
    textAlign: "left",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    padding: 12,
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(0,0,0,0.18)",
    cursor: "pointer",
    color: "white",
  },
  orgLeft: { display: "grid", gap: 4 },
  orgName: { fontWeight: 850 },
  orgPath: { fontSize: 12, color: "rgba(255,255,255,0.62)" },
  orgRight: { display: "flex", alignItems: "center", gap: 10 },
  pill: {
    borderRadius: 999,
    padding: "6px 10px",
    background: "rgba(255,255,255,0.10)",
    border: "1px solid rgba(255,255,255,0.12)",
    fontSize: 12,
    fontWeight: 800,
  },

  empty: { padding: 18 },
  emptyTitle: { fontWeight: 950, marginBottom: 6 },
  emptyText: { color: "rgba(255,255,255,0.70)", lineHeight: 1.6 },

  form: { display: "grid", gap: 12 },
  label: { display: "grid", gap: 8, fontSize: 12, color: "rgba(255,255,255,0.72)" },
  input: {
    padding: 12,
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.14)",
    background: "rgba(0,0,0,0.28)",
    color: "white",
    outline: "none",
  },
  slugLine: { fontSize: 12, color: "rgba(255,255,255,0.70)" },
  mono: {
    fontFamily:
      "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
    color: "rgba(255,255,255,0.92)",
  },

  primaryBtnFull: {
    height: 42,
    borderRadius: 14,
    fontWeight: 950,
    cursor: "pointer",
    background: "rgba(255,255,255,0.92)",
    color: "#000",
    border: "1px solid rgba(255,255,255,0.16)",
  },
  linkBtn: {
    background: "transparent",
    border: "none",
    color: "rgba(255,255,255,0.85)",
    cursor: "pointer",
    fontWeight: 850,
    padding: 0,
    justifySelf: "start",
  },

  callout: {
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(0,0,0,0.22)",
    padding: 14,
    display: "grid",
    gap: 8,
  },
  calloutTitle: { fontWeight: 950 },
  calloutText: { color: "rgba(255,255,255,0.70)", lineHeight: 1.6, fontSize: 13 },

  footer: { marginTop: 18, paddingTop: 12 },
  footerText: { fontSize: 12, color: "rgba(255,255,255,0.55)" },

  center: { minHeight: "100vh", display: "grid", placeItems: "center", padding: 18 },
  card: {
    width: "min(520px, 100%)",
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,0.14)",
    background: "rgba(255,255,255,0.06)",
    padding: 18,
  },
  skeletonTitle: {
    height: 18,
    width: "60%",
    borderRadius: 10,
    background: "rgba(255,255,255,0.10)",
  },
  skeletonLine: {
    height: 12,
    width: "90%",
    borderRadius: 10,
    marginTop: 10,
    background: "rgba(255,255,255,0.08)",
  },
  orgSkeleton: {
    height: 56,
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.05)",
  },
};