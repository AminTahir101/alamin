-- Reports module

create table if not exists public.report_definitions (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.organizations(id) on delete cascade,
  cycle_id uuid references public.quarterly_cycles(id) on delete set null,
  department_id uuid references public.departments(id) on delete set null,
  title text not null,
  description text,
  cadence text not null default 'monthly' check (cadence in ('weekly','bi_weekly','monthly','quarterly','bi_annual','annual','custom')),
  custom_label text,
  custom_date_from date,
  custom_date_to date,
  recipients text[] not null default '{}',
  export_formats text[] not null default '{json,csv}',
  include_company_summary boolean not null default true,
  include_department_breakdown boolean not null default true,
  include_objectives boolean not null default true,
  include_okrs boolean not null default true,
  include_kpis boolean not null default true,
  include_tasks boolean not null default true,
  auto_generate boolean not null default true,
  auto_email boolean not null default true,
  is_active boolean not null default true,
  filters jsonb not null default '{}'::jsonb,
  last_generated_at timestamp with time zone,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamp with time zone not null default now(),
  updated_at timestamp with time zone not null default now()
);

create index if not exists idx_report_definitions_org_id on public.report_definitions(org_id);
create index if not exists idx_report_definitions_cycle_id on public.report_definitions(cycle_id);
create index if not exists idx_report_definitions_department_id on public.report_definitions(department_id);

create table if not exists public.report_runs (
  id uuid primary key default gen_random_uuid(),
  report_definition_id uuid not null references public.report_definitions(id) on delete cascade,
  org_id uuid not null references public.organizations(id) on delete cascade,
  cycle_id uuid references public.quarterly_cycles(id) on delete set null,
  status text not null default 'generated' check (status in ('generated','emailed','failed')),
  period_label text not null,
  date_from date,
  date_to date,
  report_payload jsonb not null default '{}'::jsonb,
  report_text text,
  exported_formats text[] not null default '{}',
  emailed_to text[] not null default '{}',
  email_status text not null default 'pending' check (email_status in ('pending','sent','failed','skipped')),
  email_error text,
  generated_by uuid references auth.users(id) on delete set null,
  generated_at timestamp with time zone not null default now()
);

create index if not exists idx_report_runs_definition_id on public.report_runs(report_definition_id);
create index if not exists idx_report_runs_org_id on public.report_runs(org_id);
create index if not exists idx_report_runs_generated_at on public.report_runs(generated_at desc);
